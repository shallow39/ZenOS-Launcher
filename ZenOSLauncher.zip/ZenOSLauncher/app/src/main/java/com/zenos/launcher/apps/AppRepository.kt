package com.zenos.launcher.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.graphics.drawable.Drawable
import android.os.Process
import android.os.UserManager
import com.zenos.launcher.model.AppRef

data class AppEntry(
    val label: String,
    val packageName: String,
    val userSerial: Long,
    val icon: Drawable,
    val category: String,
    val component: String
)

class AppRepository(private val context: Context) {
    private var cache: List<AppEntry> = emptyList()

    fun apps(): List<AppEntry> {
        if (cache.isEmpty()) refresh()
        return cache
    }

    fun refresh(): List<AppEntry> {
        val launcherApps = context.getSystemService(LauncherApps::class.java)
        val userManager = context.getSystemService(UserManager::class.java)
        val found = mutableListOf<AppEntry>()
        val profiles = try {
            userManager.userProfiles
        } catch (_: Exception) {
            listOf(Process.myUserHandle())
        }
        profiles.forEach { user ->
            val serial = try {
                userManager.getSerialNumberForUser(user)
            } catch (_: Exception) {
                0L
            }
            val activities = try {
                launcherApps.getActivityList(null, user)
            } catch (_: Exception) {
                emptyList()
            }
            activities.forEach { info ->
                try {
                    val pkg = info.applicationInfo.packageName
                    val label = info.label?.toString()?.ifBlank { pkg } ?: pkg
                    val icon = info.getBadgedIcon(context.resources.displayMetrics.densityDpi)
                    found += AppEntry(
                        label = label,
                        packageName = pkg,
                        userSerial = serial,
                        icon = icon,
                        category = categorize(pkg, label, info.applicationInfo.category),
                        component = info.componentName.flattenToShortString()
                    )
                } catch (_: Exception) {
                }
            }
        }
        cache = found.distinctBy { it.packageName + "#" + it.userSerial }
            .sortedBy { it.label.lowercase() }
        return cache
    }

    fun find(ref: AppRef): AppEntry? = apps().firstOrNull {
        it.packageName == ref.packageName && it.userSerial == ref.userSerial
    } ?: apps().firstOrNull { it.packageName == ref.packageName }

    fun findByPackage(pkg: String): AppEntry? = apps().firstOrNull { it.packageName == pkg }

    fun launch(ref: AppRef): Boolean {
        return try {
            val launcherApps = context.getSystemService(LauncherApps::class.java)
            val userManager = context.getSystemService(UserManager::class.java)
            val user = userManager.userProfiles.firstOrNull {
                try {
                    userManager.getSerialNumberForUser(it) == ref.userSerial
                } catch (_: Exception) {
                    false
                }
            } ?: Process.myUserHandle()
            val list = launcherApps.getActivityList(ref.packageName, user)
            if (list.isNullOrEmpty()) {
                val intent = context.packageManager.getLaunchIntentForPackage(ref.packageName) ?: return false
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                launcherApps.startMainActivity(list[0].componentName, user, null, null)
            }
            com.zenos.launcher.data.ZenStore.recordLaunch(ref.packageName)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun invalidate() {
        cache = emptyList()
    }

    companion object {
        fun categorize(pkg: String, label: String, category: Int): String {
            val blob = (pkg + " " + label).lowercase()
            return when {
                category == ApplicationInfo.CATEGORY_GAME || blob.contains("game") -> "Games"
                category == ApplicationInfo.CATEGORY_SOCIAL ||
                    listOf("facebook", "instagram", "twitter", "snapchat", "tiktok", "reddit").any { blob.contains(it) } -> "Social"
                category == ApplicationInfo.CATEGORY_AUDIO || category == ApplicationInfo.CATEGORY_VIDEO ||
                    listOf("music", "video", "youtube", "spotify", "netflix").any { blob.contains(it) } -> "Media"
                category == ApplicationInfo.CATEGORY_IMAGE ||
                    listOf("camera", "photo", "gallery").any { blob.contains(it) } -> "Photography"
                listOf("dialer", "mms", "messaging", "telegram", "whatsapp", "signal").any { blob.contains(it) } -> "Communication"
                listOf("docs", "sheet", "office", "notes", "calendar", "mail").any { blob.contains(it) } -> "Productivity"
                listOf("duolingo", "classroom", "school", "learn").any { blob.contains(it) } -> "Education"
                category == ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
                listOf("settings", "files", "calculator", "clock", "tool").any { blob.contains(it) } -> "Tools"
                else -> "Other"
            }
        }
    }
}
