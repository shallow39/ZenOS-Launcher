package com.zenos.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zenos.launcher.model.AnimCatalog
import com.zenos.launcher.model.AnimClip
import com.zenos.launcher.model.AppRef
import com.zenos.launcher.model.Folder
import com.zenos.launcher.model.HomeItem
import com.zenos.launcher.model.HomeLayout
import com.zenos.launcher.model.HomePage
import com.zenos.launcher.model.ZenSettings
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val Context.zenDataStore by preferencesDataStore(name = "zenos_settings")

object ZenStore {
    lateinit var appContext: Context
        private set
    var settings = ZenSettings()
    var layout = HomeLayout()
    var activePreset: String = "Zen Spring"
    val presets: MutableMap<String, MutableMap<String, AnimClip>> = mutableMapOf()
    private val genKey = intPreferencesKey("generation")
    private val themeKey = stringPreferencesKey("theme_mode")

    fun init(context: Context) {
        appContext = context.applicationContext
        load()
        if (presets.isEmpty()) seedPresets()
    }

    fun load() {
        readSettings()
        readLayout()
        readAnimations()
        runBlocking {
            val prefs = appContext.zenDataStore.data.first()
            val mirrored = prefs[themeKey]
            if (!mirrored.isNullOrBlank() && settings.themeMode.isBlank()) {
                settings.themeMode = mirrored
            }
        }
    }

    fun save() {
        writeSettings()
        writeLayout()
        writeAnimations()
        runBlocking {
            appContext.zenDataStore.edit { prefs ->
                prefs[themeKey] = settings.themeMode
                prefs[genKey] = (prefs[genKey] ?: 0) + 1
            }
        }
    }

    fun recordLaunch(packageName: String) {
        settings.recentLaunches.remove(packageName)
        settings.recentLaunches.add(0, packageName)
        while (settings.recentLaunches.size > 12) {
            settings.recentLaunches.removeAt(settings.recentLaunches.lastIndex)
        }
        writeSettings()
    }

    fun pushSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        settings.searchHistory.remove(q)
        settings.searchHistory.add(0, q)
        while (settings.searchHistory.size > 8) {
            settings.searchHistory.removeAt(settings.searchHistory.lastIndex)
        }
        writeSettings()
    }

    fun clip(category: String): AnimClip {
        val preset = presets.getOrPut(activePreset) { mutableMapOf() }
        return preset.getOrPut(category) { AnimCatalog.defaultClip(category) }
    }

    fun seedPresets() {
        presets.clear()
        listOf("iOS Smooth", "Zen Spring", "Liquid Morph", "Hyper Smooth", "Fast", "Minimal", "Custom 1").forEach { name ->
            val map = mutableMapOf<String, AnimClip>()
            AnimCatalog.categories.forEach { cat ->
                val clip = AnimCatalog.defaultClip(cat)
                when (name) {
                    "Fast" -> clip.duration = 140
                    "Minimal" -> {
                        clip.duration = 180
                        clip.fromY = 0f
                        clip.easing = "Ease Out"
                    }
                    "iOS Smooth" -> {
                        clip.duration = 340
                        clip.easing = "Ease In Out"
                        clip.overshoot = 1.02f
                    }
                    "Liquid Morph" -> {
                        clip.duration = 420
                        clip.easing = "Spring"
                        clip.fromScale = 0.86f
                        clip.fromBlur = 16f
                    }
                    "Hyper Smooth" -> {
                        clip.duration = 300
                        clip.easing = "Quintic"
                    }
                }
                map[cat] = clip
            }
            presets[name] = map
        }
        activePreset = "Zen Spring"
        writeAnimations()
    }

    fun exportThemeJson(name: String): JSONObject {
        val root = JSONObject()
        root.put("format", "zenos-theme")
        root.put("version", 1)
        root.put("name", name)
        root.put("settings", settingsJson())
        root.put("preset", activePreset)
        root.put("animations", animationsJson())
        return root
    }

    fun importThemeJson(text: String): Boolean {
        return try {
            val root = JSONObject(text)
            if (root.optString("format") != "zenos-theme") return false
            val s = root.optJSONObject("settings") ?: return false
            applySettingsJson(s)
            activePreset = root.optString("preset", activePreset)
            val anim = root.optJSONObject("animations")
            if (anim != null) applyAnimationsJson(anim)
            save()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun settingsFile() = File(appContext.filesDir, "settings.json")
    private fun layoutFile() = File(appContext.filesDir, "layout.json")
    private fun animFile() = File(appContext.filesDir, "animations.json")

    private fun writeAtomic(file: File, text: String) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(file)) {
            file.writeText(text)
            tmp.delete()
        }
    }

    private fun settingsJson(): JSONObject {
        val s = settings
        return JSONObject().apply {
            put("themeMode", s.themeMode)
            put("accent", s.accent)
            put("iconSize", s.iconSize)
            put("showLabels", s.showLabels)
            put("iconShape", s.iconShape)
            put("gridCols", s.gridCols)
            put("gridRows", s.gridRows)
            put("dockSlots", s.dockSlots)
            put("pageIndicator", s.pageIndicator)
            put("blurEnabled", s.blurEnabled)
            put("glassEnabled", s.glassEnabled)
            put("glassBlur", s.glassBlur)
            put("glassAlpha", s.glassAlpha)
            put("glassSaturation", s.glassSaturation)
            put("glassBrightness", s.glassBrightness)
            put("glassHighlight", s.glassHighlight)
            put("glassBorder", s.glassBorder)
            put("glassShadow", s.glassShadow)
            put("glassRefraction", s.glassRefraction)
            put("glassTint", s.glassTint)
            put("animSpeed", s.animSpeed)
            put("pageTransition", s.pageTransition)
            put("folderAnim", s.folderAnim)
            put("reduceMotion", s.reduceMotion)
            put("performanceMode", s.performanceMode)
            put("lowEnd", s.lowEnd)
            put("addNewApps", s.addNewApps)
            put("wallpaperDim", s.wallpaperDim)
            put("wallpaperBlur", s.wallpaperBlur)
            put("parallax", s.parallax)
            put("wallpaperPreset", s.wallpaperPreset)
            put("weatherConsent", s.weatherConsent)
            put("onboardingDone", s.onboardingDone)
            put("gestureUp", s.gestureUp)
            put("gestureDown", s.gestureDown)
            put("gestureRight", s.gestureRight)
            put("gestureControl", s.gestureControl)
            put("todayClock", s.todayClock)
            put("todayWeather", s.todayWeather)
            put("todayBattery", s.todayBattery)
            put("todayRecent", s.todayRecent)
            put("todayCalendar", s.todayCalendar)
            put("searchHistory", JSONArray(s.searchHistory))
            put("recentLaunches", JSONArray(s.recentLaunches))
        }
    }

    private fun applySettingsJson(o: JSONObject) {
        val s = settings
        s.themeMode = o.optString("themeMode", s.themeMode)
        s.accent = o.optString("accent", s.accent)
        s.iconSize = o.optString("iconSize", s.iconSize)
        s.showLabels = o.optBoolean("showLabels", s.showLabels)
        s.iconShape = o.optString("iconShape", s.iconShape)
        s.gridCols = o.optInt("gridCols", s.gridCols).coerceIn(3, 6)
        s.gridRows = o.optInt("gridRows", s.gridRows).coerceIn(4, 7)
        s.dockSlots = o.optInt("dockSlots", s.dockSlots).coerceIn(3, 6)
        s.pageIndicator = o.optBoolean("pageIndicator", s.pageIndicator)
        s.blurEnabled = o.optBoolean("blurEnabled", s.blurEnabled)
        s.glassEnabled = o.optBoolean("glassEnabled", s.glassEnabled)
        s.glassBlur = o.optInt("glassBlur", s.glassBlur).coerceIn(0, 100)
        s.glassAlpha = o.optInt("glassAlpha", s.glassAlpha).coerceIn(0, 100)
        s.glassSaturation = o.optInt("glassSaturation", s.glassSaturation).coerceIn(0, 100)
        s.glassBrightness = o.optInt("glassBrightness", s.glassBrightness).coerceIn(0, 100)
        s.glassHighlight = o.optInt("glassHighlight", s.glassHighlight).coerceIn(0, 100)
        s.glassBorder = o.optInt("glassBorder", s.glassBorder).coerceIn(0, 100)
        s.glassShadow = o.optInt("glassShadow", s.glassShadow).coerceIn(0, 100)
        s.glassRefraction = o.optInt("glassRefraction", s.glassRefraction).coerceIn(0, 100)
        s.glassTint = o.optString("glassTint", s.glassTint)
        s.animSpeed = o.optString("animSpeed", s.animSpeed)
        s.pageTransition = o.optString("pageTransition", s.pageTransition)
        s.folderAnim = o.optBoolean("folderAnim", s.folderAnim)
        s.reduceMotion = o.optBoolean("reduceMotion", s.reduceMotion)
        s.performanceMode = o.optString("performanceMode", s.performanceMode)
        s.lowEnd = o.optBoolean("lowEnd", s.lowEnd)
        s.addNewApps = o.optBoolean("addNewApps", s.addNewApps)
        s.wallpaperDim = o.optInt("wallpaperDim", s.wallpaperDim).coerceIn(0, 80)
        s.wallpaperBlur = o.optInt("wallpaperBlur", s.wallpaperBlur).coerceIn(0, 100)
        s.parallax = o.optBoolean("parallax", s.parallax)
        s.wallpaperPreset = o.optString("wallpaperPreset", s.wallpaperPreset)
        s.weatherConsent = o.optBoolean("weatherConsent", s.weatherConsent)
        s.onboardingDone = o.optBoolean("onboardingDone", s.onboardingDone)
        s.gestureUp = o.optBoolean("gestureUp", s.gestureUp)
        s.gestureDown = o.optBoolean("gestureDown", s.gestureDown)
        s.gestureRight = o.optBoolean("gestureRight", s.gestureRight)
        s.gestureControl = o.optBoolean("gestureControl", s.gestureControl)
        s.todayClock = o.optBoolean("todayClock", s.todayClock)
        s.todayWeather = o.optBoolean("todayWeather", s.todayWeather)
        s.todayBattery = o.optBoolean("todayBattery", s.todayBattery)
        s.todayRecent = o.optBoolean("todayRecent", s.todayRecent)
        s.todayCalendar = o.optBoolean("todayCalendar", s.todayCalendar)
        s.searchHistory = jsonStringList(o.optJSONArray("searchHistory"))
        s.recentLaunches = jsonStringList(o.optJSONArray("recentLaunches"))
    }

    private fun writeSettings() = writeAtomic(settingsFile(), settingsJson().toString())
    private fun readSettings() {
        val f = settingsFile()
        if (!f.exists()) return
        try {
            applySettingsJson(JSONObject(f.readText()))
        } catch (_: Exception) {
        }
    }

    private fun itemJson(item: HomeItem) = JSONObject().apply {
        put("id", item.id)
        put("type", item.type)
        put("packageName", item.packageName)
        put("userSerial", item.userSerial)
        put("folderId", item.folderId)
        put("widgetKind", item.widgetKind)
        put("appWidgetId", item.appWidgetId)
        put("col", item.col)
        put("row", item.row)
        put("spanX", item.spanX)
        put("spanY", item.spanY)
    }

    private fun parseItem(o: JSONObject) = HomeItem(
        id = o.optString("id", UUID.randomUUID().toString()),
        type = o.optString("type", "app"),
        packageName = o.optString("packageName"),
        userSerial = o.optLong("userSerial"),
        folderId = o.optString("folderId"),
        widgetKind = o.optString("widgetKind"),
        appWidgetId = o.optInt("appWidgetId", -1),
        col = o.optInt("col"),
        row = o.optInt("row"),
        spanX = o.optInt("spanX", 1),
        spanY = o.optInt("spanY", 1)
    )

    private fun writeLayout() {
        val root = JSONObject()
        val pages = JSONArray()
        layout.pages.forEach { page ->
            val p = JSONObject()
            p.put("id", page.id)
            val items = JSONArray()
            page.items.forEach { items.put(itemJson(it)) }
            p.put("items", items)
            pages.put(p)
        }
        root.put("pages", pages)
        val dock = JSONArray()
        layout.dock.forEach {
            dock.put(JSONObject().put("packageName", it.packageName).put("userSerial", it.userSerial))
        }
        root.put("dock", dock)
        val folders = JSONObject()
        layout.folders.values.forEach { folder ->
            val f = JSONObject()
            f.put("id", folder.id)
            f.put("name", folder.name)
            val apps = JSONArray()
            folder.apps.forEach { apps.put(JSONObject().put("packageName", it.packageName).put("userSerial", it.userSerial)) }
            f.put("apps", apps)
            folders.put(folder.id, f)
        }
        root.put("folders", folders)
        root.put("hidden", JSONArray(layout.hidden))
        writeAtomic(layoutFile(), root.toString())
    }

    private fun readLayout() {
        val f = layoutFile()
        if (!f.exists()) return
        try {
            val root = JSONObject(f.readText())
            val pages = mutableListOf<HomePage>()
            val pageArr = root.optJSONArray("pages") ?: JSONArray()
            for (i in 0 until pageArr.length()) {
                val p = pageArr.getJSONObject(i)
                val items = mutableListOf<HomeItem>()
                val arr = p.optJSONArray("items") ?: JSONArray()
                for (j in 0 until arr.length()) items += parseItem(arr.getJSONObject(j))
                pages += HomePage(p.optString("id", UUID.randomUUID().toString()), items)
            }
            val dock = mutableListOf<AppRef>()
            val dockArr = root.optJSONArray("dock") ?: JSONArray()
            for (i in 0 until dockArr.length()) {
                val d = dockArr.getJSONObject(i)
                dock += AppRef(d.optString("packageName"), d.optLong("userSerial"))
            }
            val folders = mutableMapOf<String, Folder>()
            val fmap = root.optJSONObject("folders") ?: JSONObject()
            fmap.keys().forEach { key ->
                val fo = fmap.getJSONObject(key)
                val apps = mutableListOf<AppRef>()
                val aa = fo.optJSONArray("apps") ?: JSONArray()
                for (i in 0 until aa.length()) {
                    val a = aa.getJSONObject(i)
                    apps += AppRef(a.optString("packageName"), a.optLong("userSerial"))
                }
                val folder = Folder(fo.optString("id", key), fo.optString("name", "Folder"), apps)
                folders[folder.id] = folder
            }
            layout = HomeLayout(pages, dock, folders, jsonStringList(root.optJSONArray("hidden")))
        } catch (_: Exception) {
            layout = HomeLayout()
        }
    }

    private fun animationsJson(): JSONObject {
        val root = JSONObject()
        root.put("active", activePreset)
        val all = JSONObject()
        presets.forEach { (name, map) ->
            val preset = JSONObject()
            map.forEach { (cat, clip) ->
                preset.put(cat, JSONObject().apply {
                    put("duration", clip.duration)
                    put("delay", clip.delay)
                    put("fromScale", clip.fromScale.toDouble())
                    put("toScale", clip.toScale.toDouble())
                    put("fromAlpha", clip.fromAlpha.toDouble())
                    put("toAlpha", clip.toAlpha.toDouble())
                    put("fromRot", clip.fromRot.toDouble())
                    put("toRot", clip.toRot.toDouble())
                    put("fromX", clip.fromX.toDouble())
                    put("toX", clip.toX.toDouble())
                    put("fromY", clip.fromY.toDouble())
                    put("toY", clip.toY.toDouble())
                    put("fromBlur", clip.fromBlur.toDouble())
                    put("toBlur", clip.toBlur.toDouble())
                    put("corner", clip.corner.toDouble())
                    put("shadow", clip.shadow.toDouble())
                    put("stiffness", clip.stiffness.toDouble())
                    put("damping", clip.damping.toDouble())
                    put("bounce", clip.bounce.toDouble())
                    put("overshoot", clip.overshoot.toDouble())
                    put("easing", clip.easing)
                })
            }
            all.put(name, preset)
        }
        root.put("presets", all)
        return root
    }

    private fun applyAnimationsJson(root: JSONObject) {
        val presetRoot = if (root.has("presets")) root else JSONObject().put("presets", root).put("active", activePreset)
        activePreset = presetRoot.optString("active", activePreset)
        val all = presetRoot.optJSONObject("presets") ?: return
        presets.clear()
        all.keys().forEach { name ->
            val map = mutableMapOf<String, AnimClip>()
            val preset = all.getJSONObject(name)
            preset.keys().forEach { cat ->
                val o = preset.getJSONObject(cat)
                map[cat] = AnimClip(
                    duration = o.optInt("duration", 320),
                    delay = o.optInt("delay", 0),
                    fromScale = o.optDouble("fromScale", 0.94).toFloat(),
                    toScale = o.optDouble("toScale", 1.0).toFloat(),
                    fromAlpha = o.optDouble("fromAlpha", 0.0).toFloat(),
                    toAlpha = o.optDouble("toAlpha", 1.0).toFloat(),
                    fromRot = o.optDouble("fromRot", 0.0).toFloat(),
                    toRot = o.optDouble("toRot", 0.0).toFloat(),
                    fromX = o.optDouble("fromX", 0.0).toFloat(),
                    toX = o.optDouble("toX", 0.0).toFloat(),
                    fromY = o.optDouble("fromY", 24.0).toFloat(),
                    toY = o.optDouble("toY", 0.0).toFloat(),
                    fromBlur = o.optDouble("fromBlur", 8.0).toFloat(),
                    toBlur = o.optDouble("toBlur", 0.0).toFloat(),
                    corner = o.optDouble("corner", 28.0).toFloat(),
                    shadow = o.optDouble("shadow", 0.25).toFloat(),
                    stiffness = o.optDouble("stiffness", 380.0).toFloat(),
                    damping = o.optDouble("damping", 0.72).toFloat(),
                    bounce = o.optDouble("bounce", 0.1).toFloat(),
                    overshoot = o.optDouble("overshoot", 1.15).toFloat(),
                    easing = o.optString("easing", "Spring")
                )
            }
            presets[name] = map
        }
    }

    private fun writeAnimations() = writeAtomic(animFile(), animationsJson().toString())
    private fun readAnimations() {
        val f = animFile()
        if (!f.exists()) return
        try {
            applyAnimationsJson(JSONObject(f.readText()))
        } catch (_: Exception) {
        }
    }

    private fun jsonStringList(arr: JSONArray?): MutableList<String> {
        val out = mutableListOf<String>()
        if (arr == null) return out
        for (i in 0 until arr.length()) out += arr.optString(i)
        return out
    }
}
