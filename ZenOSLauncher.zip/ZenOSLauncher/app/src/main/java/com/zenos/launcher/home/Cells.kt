package com.zenos.launcher.home

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.zenos.launcher.R
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.model.AppRef
import com.zenos.launcher.model.HomeItem

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun iconSizePx(context: Context): Int {
    val dp = when (ZenStore.settings.iconSize) {
        "small" -> 48
        "large" -> 68
        else -> 56
    }
    return context.dp(dp)
}

fun maskIcon(context: Context, source: Drawable, size: Int): Drawable {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val path = Path()
    val radius = when (ZenStore.settings.iconShape) {
        "circle" -> size / 2f
        "square" -> size * 0.08f
        "rounded" -> size * 0.22f
        else -> size * 0.34f
    }
    path.addRoundRect(0f, 0f, size.toFloat(), size.toFloat(), radius, radius, Path.Direction.CW)
    canvas.clipPath(path)
    source.mutate().apply {
        setBounds(0, 0, size, size)
        draw(canvas)
    }
    return BitmapDrawable(context.resources, bmp)
}

class AppCellView(context: Context) : LinearLayout(context) {
    val icon = ImageView(context)
    val label = TextView(context)
    val badge = TextView(context)
    var itemId: String = ""
    var appRef: AppRef? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        val size = iconSizePx(context)
        icon.layoutParams = LayoutParams(size, size)
        label.gravity = Gravity.CENTER
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        label.setTextColor(context.getColor(R.color.zen_text))
        label.maxLines = 1
        badge.text = "–"
        badge.setTextColor(context.getColor(R.color.zen_danger))
        badge.textSize = 16f
        badge.setBackgroundColor(0xCCFFFFFF.toInt())
        badge.gravity = Gravity.CENTER
        badge.visibility = View.GONE
        badge.contentDescription = context.getString(R.string.cd_remove, "")
        val wrap = FrameLayout(context)
        wrap.addView(icon)
        val bp = FrameLayout.LayoutParams(context.dp(22), context.dp(22), Gravity.END or Gravity.TOP)
        wrap.addView(badge, bp)
        addView(wrap)
        addView(label, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    fun bindLabel(text: String) {
        label.text = text
        label.visibility = if (ZenStore.settings.showLabels) View.VISIBLE else View.GONE
        contentDescription = context.getString(R.string.cd_app_icon, text)
        badge.contentDescription = context.getString(R.string.cd_remove, text)
    }
}

class FolderPreview(context: Context) : LinearLayout(context) {
    val iconBox = FrameLayout(context)
    val label = TextView(context)
    val badge = TextView(context)
    var itemId: String = ""
    var folderId: String = ""

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        val size = iconSizePx(context)
        iconBox.layoutParams = LayoutParams(size, size)
        iconBox.setBackgroundColor(0x66FFFFFF)
        label.gravity = Gravity.CENTER
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        label.setTextColor(context.getColor(R.color.zen_text))
        badge.text = "–"
        badge.gravity = Gravity.CENTER
        badge.visibility = View.GONE
        val wrap = FrameLayout(context)
        wrap.addView(iconBox, FrameLayout.LayoutParams(size, size))
        wrap.addView(badge, FrameLayout.LayoutParams(context.dp(22), context.dp(22), Gravity.END or Gravity.TOP))
        addView(wrap)
        addView(label)
    }
}

interface HomeHost {
    fun onOpenApp(ref: AppRef)
    fun onOpenFolder(folderId: String)
    fun onRemoveItem(item: HomeItem)
    fun onDropItem(itemId: String, pageIndex: Int, col: Int, row: Int, targetId: String?)
    fun onDropToDock(itemId: String, slot: Int)
    fun requestEdit()
    fun isEditing(): Boolean
}
