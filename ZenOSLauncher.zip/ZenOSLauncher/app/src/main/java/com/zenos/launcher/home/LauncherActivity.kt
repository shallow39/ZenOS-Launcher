package com.zenos.launcher.home

import android.Manifest
import android.app.role.RoleManager
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.zenos.launcher.R
import com.zenos.launcher.anim.AnimEngine
import com.zenos.launcher.apps.AppRepository
import com.zenos.launcher.control.ControlCenterView
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.glass.GlassPanel
import com.zenos.launcher.library.AppLibraryActivity
import com.zenos.launcher.model.AppRef
import com.zenos.launcher.model.HomeItem
import com.zenos.launcher.model.HomePage
import com.zenos.launcher.notify.NotificationDashboardActivity
import com.zenos.launcher.search.SearchActivity
import com.zenos.launcher.settings.SettingsActivity
import com.zenos.launcher.widgets.ZenWidgetHost
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class LauncherActivity : AppCompatActivity(), HomeHost {
    private val repo by lazy { AppRepository(this) }
    private val widgetHost by lazy { ZenWidgetHost(this, 0x5E40) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var dim: View
    private lateinit var pager: ViewPager2
    private lateinit var dock: DockView
    private lateinit var dots: LinearLayout
    private lateinit var editBar: LinearLayout
    private lateinit var control: ControlCenterView
    private lateinit var scrim: View
    private var editing = false
    private var torchOn = false
    private var torchId: String? = null
    private var downX = 0f
    private var downY = 0f
    private var tracking = false

    private val pickWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = result.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (result.resultCode != RESULT_OK || id == -1) {
            if (id != -1) widgetHost.deleteAppWidgetId(id)
            return@registerForActivityResult
        }
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
        val page = currentHomePage() ?: return@registerForActivityResult
        page.items += HomeItem(
            type = "awidget",
            widgetKind = info?.provider?.className ?: "widget",
            appWidgetId = id,
            col = 0,
            row = 0,
            spanX = 4,
            spanY = 2
        )
        ZenStore.save()
        refreshPager()
    }

    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadWeather()
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val pkg = intent?.data?.schemeSpecificPart ?: return
            repo.invalidate()
            repo.refresh()
            when (intent.action) {
                Intent.ACTION_PACKAGE_REMOVED -> {
                    if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                    removePackage(pkg)
                }
                Intent.ACTION_PACKAGE_ADDED -> {
                    if (ZenStore.settings.addNewApps && !intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) {
                        addNewApp(pkg)
                    } else refreshPager()
                }
                else -> refreshPager()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo.refresh()
        seedIfNeeded()
        buildUi()
        try {
            widgetHost.startListening()
        } catch (_: Exception) {
        }
        registerPackageMonitor()
        if (!ZenStore.settings.onboardingDone) showOnboarding()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        closeOverlays()
        val homeIndex = if (ZenStore.settings.gestureRight) 1 else 0
        if (::pager.isInitialized && pager.currentItem != homeIndex) pager.setCurrentItem(homeIndex, false)
    }

    override fun onResume() {
        super.onResume()
        repo.refresh()
        pruneMissing()
        refreshPager()
        dock.rebuild()
        loadWeather()
        handler.postDelayed(tick, 30_000)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
        try {
            widgetHost.stopListening()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshPager()
            handler.postDelayed(this, 30_000)
        }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        wallpaper = ImageView(this)
        wallpaper.scaleType = ImageView.ScaleType.CENTER_CROP
        dim = View(this)
        pager = ViewPager2(this)
        pager.adapter = PageAdapter()
        pager.offscreenPageLimit = 1
        dock = DockView(this, this, repo)
        dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER
        dots.contentDescription = getString(R.string.cd_page_indicator)
        editBar = LinearLayout(this)
        editBar.orientation = LinearLayout.HORIZONTAL
        editBar.gravity = Gravity.CENTER
        editBar.visibility = View.GONE
        control = ControlCenterView(this)
        control.visibility = View.GONE
        scrim = View(this)
        scrim.setBackgroundColor(getColor(R.color.zen_scrim))
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeOverlays() }
        scrim.contentDescription = getString(R.string.close)
        root.addView(wallpaper, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(dim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(pager, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val dockLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84), Gravity.BOTTOM)
        dockLp.leftMargin = dp(18)
        dockLp.rightMargin = dp(18)
        dockLp.bottomMargin = dp(18)
        root.addView(dock, dockLp)
        root.addView(dots, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), Gravity.BOTTOM).apply { bottomMargin = dp(108) })
        root.addView(editBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64), Gravity.TOP).apply { topMargin = dp(36) })
        root.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(control, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360), Gravity.TOP).apply {
            leftMargin = dp(12)
            rightMargin = dp(12)
            topMargin = dp(28)
        })
        setContentView(root)
        root.setOnTouchListener { _, event -> handleGesture(event) }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, offset: Float, offsetPixels: Int) {
                if (ZenStore.settings.parallax) wallpaper.translationX = -(position + offset) * dp(18)
                paintDots(position)
            }
        })
        wireControl()
        applyWallpaper()
        dock.rebuild()
        val start = if (ZenStore.settings.gestureRight && pager.adapter!!.itemCount > 1) 1 else 0
        pager.setCurrentItem(start, false)
        paintDots(start)
    }

    private fun wireControl() {
        control.wifi.setOnClickListener { control.open(Settings.Panel.ACTION_WIFI); closeOverlays() }
        control.bluetooth.setOnClickListener { control.open(Settings.Panel.ACTION_BLUETOOTH); closeOverlays() }
        control.volume.setOnClickListener { control.open(Settings.Panel.ACTION_VOLUME); closeOverlays() }
        control.settings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)); closeOverlays() }
        control.battery.setOnClickListener { startActivity(Intent(this, NotificationDashboardActivity::class.java)); closeOverlays() }
        control.flash.setOnClickListener { toggleTorch() }
        control.rotate.setOnClickListener { toggleRotation() }
        control.dark.setOnClickListener { toggleDark() }
        control.brightness.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (Settings.System.canWrite(this@LauncherActivity)) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress.coerceIn(1, 255))
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {
                if (!Settings.System.canWrite(this@LauncherActivity)) {
                    Toast.makeText(this@LauncherActivity, getString(R.string.open_system_panel), Toast.LENGTH_SHORT).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                }
            }
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        try {
            control.brightness.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (_: Exception) {
        }
        control.battery.text = getString(R.string.tile_battery) + " " + BuiltinWidgetView.batteryPercent(this) + "%"
    }

    private fun handleGesture(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                tracking = true
                return false
            }
            MotionEvent.ACTION_UP -> {
                if (!tracking) return false
                val dx = event.x - downX
                val dy = event.y - downY
                tracking = false
                val threshold = dp(72)
                if (kotlin.math.abs(dy) < threshold || kotlin.math.abs(dy) < kotlin.math.abs(dx)) return false
                if (dy > 0 && downY < dp(140) && downX > root.width * 0.62f && ZenStore.settings.gestureControl) {
                    showControl()
                    return true
                }
                if (dy < 0 && ZenStore.settings.gestureUp) {
                    startActivity(Intent(this, AppLibraryActivity::class.java))
                    AnimEngine.play(pager, "App Library entrance")
                    return true
                }
                if (dy > 0 && ZenStore.settings.gestureDown) {
                    startActivity(Intent(this, SearchActivity::class.java))
                    return true
                }
            }
        }
        return false
    }

    private fun showControl() {
        scrim.visibility = View.VISIBLE
        control.visibility = View.VISIBLE
        control.refreshEffect()
        AnimEngine.play(control, "Panel entrance")
    }

    private fun closeOverlays() {
        control.visibility = View.GONE
        scrim.visibility = View.GONE
        val folder = root.findViewWithTag<View>("folder-overlay")
        if (folder != null) root.removeView(folder)
    }

    private fun applyWallpaper() {
        val preset = ZenStore.settings.wallpaperPreset
        wallpaper.setImageDrawable(
            when (preset) {
                "aurora" -> getDrawable(R.drawable.wallpaper_aurora)
                "dusk" -> getDrawable(R.drawable.wallpaper_dusk)
                "day" -> getDrawable(R.drawable.wallpaper_day)
                else -> null
            }
        )
        dim.setBackgroundColor(Color.argb((ZenStore.settings.wallpaperDim * 2.2f).toInt().coerceIn(0, 180), 0, 0, 0))
    }

    private fun seedIfNeeded() {
        if (ZenStore.layout.pages.isNotEmpty()) return
        val apps = repo.apps()
        val page = HomePage()
        page.items += HomeItem(type = "widget", widgetKind = "dynamic", col = 0, row = 0, spanX = 4, spanY = 2)
        var col = 0
        var row = 2
        apps.take(8).forEach { app ->
            page.items += HomeItem(type = "app", packageName = app.packageName, userSerial = app.userSerial, col = col, row = row)
            col++
            if (col >= 4) {
                col = 0
                row++
            }
        }
        ZenStore.layout.pages += page
        ZenStore.layout.dock.clear()
        apps.take(4).forEach { ZenStore.layout.dock += AppRef(it.packageName, it.userSerial) }
        ZenStore.save()
    }

    private fun pruneMissing() {
        val known = repo.apps().map { it.packageName }.toSet()
        var changed = false
        ZenStore.layout.pages.forEach { page ->
            val before = page.items.size
            page.items.removeAll { it.type == "app" && it.packageName !in known }
            if (page.items.size != before) changed = true
        }
        val dockBefore = ZenStore.layout.dock.size
        ZenStore.layout.dock.removeAll { it.packageName !in known }
        if (ZenStore.layout.dock.size != dockBefore) changed = true
        ZenStore.layout.folders.values.forEach { folder ->
            val b = folder.apps.size
            folder.apps.removeAll { it.packageName !in known }
            if (folder.apps.size != b) changed = true
        }
        if (changed) ZenStore.save()
    }

    private fun removePackage(pkg: String) {
        ZenStore.layout.pages.forEach { it.items.removeAll { item -> item.packageName == pkg } }
        ZenStore.layout.dock.removeAll { it.packageName == pkg }
        ZenStore.layout.folders.values.forEach { it.apps.removeAll { app -> app.packageName == pkg } }
        ZenStore.save()
        refreshPager()
        dock.rebuild()
    }

    private fun addNewApp(pkg: String) {
        val entry = repo.findByPackage(pkg) ?: return
        val page = ZenStore.layout.pages.lastOrNull() ?: HomePage().also { ZenStore.layout.pages += it }
        val spot = freeCell(page) ?: return
        page.items += HomeItem(type = "app", packageName = entry.packageName, userSerial = entry.userSerial, col = spot.first, row = spot.second)
        ZenStore.save()
        refreshPager()
    }

    private fun freeCell(page: HomePage): Pair<Int, Int>? {
        val cols = ZenStore.settings.gridCols
        val rows = ZenStore.settings.gridRows
        for (r in 0 until rows) for (c in 0 until cols) {
            val taken = page.items.any { c in it.col until it.col + it.spanX && r in it.row until it.row + it.spanY }
            if (!taken) return c to r
        }
        return null
    }

    private fun refreshPager() {
        if (!::pager.isInitialized) return
        pager.adapter = PageAdapter()
        dock.rebuild()
        applyWallpaper()
        paintDots(pager.currentItem)
    }

    private fun paintDots(index: Int) {
        dots.removeAllViews()
        if (!ZenStore.settings.pageIndicator) return
        val count = pager.adapter?.itemCount ?: 0
        for (i in 0 until count) {
            val d = View(this)
            val s = dp(if (i == index) 8 else 6)
            val lp = LinearLayout.LayoutParams(s, s)
            lp.leftMargin = dp(4)
            d.setBackgroundColor(if (i == index) getColor(R.color.zen_accent) else getColor(R.color.zen_text_secondary))
            dots.addView(d, lp)
        }
    }

    private fun currentHomePage(): HomePage? {
        val offset = if (ZenStore.settings.gestureRight) 1 else 0
        val index = (pager.currentItem - offset).coerceAtLeast(0)
        return ZenStore.layout.pages.getOrNull(index)
    }

    override fun onOpenApp(ref: AppRef) {
        AnimEngine.play(pager, "App launch scale")
        if (!repo.launch(ref)) Toast.makeText(this, getString(R.string.launch_failed), Toast.LENGTH_SHORT).show()
    }

    override fun onOpenFolder(folderId: String) {
        val folder = ZenStore.layout.folders[folderId] ?: return
        val panel = GlassPanel(this)
        panel.tag = "folder-overlay"
        panel.forceRadiusDp = 28f
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))
        val name = EditText(this)
        name.setText(folder.name)
        name.contentDescription = getString(R.string.folder_name)
        col.addView(name)
        folder.apps.forEach { ref ->
            val entry = repo.find(ref)
            val row = TextView(this)
            row.text = entry?.label ?: ref.packageName
            row.setTextColor(getColor(R.color.zen_text))
            row.setPadding(0, dp(10), 0, dp(10))
            row.contentDescription = getString(R.string.cd_app_icon, row.text)
            row.setOnClickListener { onOpenApp(ref); closeOverlays() }
            row.setOnLongClickListener {
                folder.apps.remove(ref)
                ZenStore.save()
                closeOverlays()
                onOpenFolder(folderId)
                true
            }
            col.addView(row)
        }
        val actions = LinearLayout(this)
        val save = button(getString(R.string.rename)) {
            folder.name = name.text.toString().ifBlank { getString(R.string.folder_default) }
            ZenStore.save()
            closeOverlays()
            refreshPager()
        }
        val add = button(getString(R.string.add_apps)) { pickAppsForFolder(folderId) }
        val del = button(getString(R.string.delete_folder)) {
            ZenStore.layout.folders.remove(folderId)
            ZenStore.layout.pages.forEach { it.items.removeAll { item -> item.folderId == folderId } }
            ZenStore.save()
            closeOverlays()
            refreshPager()
        }
        actions.addView(save)
        actions.addView(add)
        actions.addView(del)
        col.addView(actions)
        val close = button(getString(R.string.close)) { closeOverlays() }
        col.addView(close)
        panel.addView(col)
        scrim.visibility = View.VISIBLE
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        lp.leftMargin = dp(24)
        lp.rightMargin = dp(24)
        root.addView(panel, lp)
        panel.refreshEffect()
        AnimEngine.play(panel, "Folder opening")
    }

    private fun pickAppsForFolder(folderId: String) {
        val folder = ZenStore.layout.folders[folderId] ?: return
        val options = repo.apps().filter { app -> folder.apps.none { it.packageName == app.packageName } }
        if (options.isEmpty()) return
        val labels = options.map { it.label }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.add_apps)
            .setItems(labels) { _, which ->
                val app = options[which]
                folder.apps += AppRef(app.packageName, app.userSerial)
                ZenStore.save()
                closeOverlays()
                onOpenFolder(folderId)
            }
            .show()
    }

    override fun onRemoveItem(item: HomeItem) {
        ZenStore.layout.pages.forEach { it.items.removeAll { found -> found.id == item.id } }
        if (item.type == "folder") ZenStore.layout.folders.remove(item.folderId)
        if (item.appWidgetId != -1) {
            try {
                widgetHost.deleteAppWidgetId(item.appWidgetId)
            } catch (_: Exception) {
            }
        }
        ZenStore.save()
        refreshPager()
    }

    override fun onDropItem(itemId: String, pageIndex: Int, col: Int, row: Int, targetId: String?) {
        if (itemId.startsWith("dock:")) {
            val index = itemId.removePrefix("dock:").toIntOrNull() ?: return
            val ref = ZenStore.layout.dock.getOrNull(index) ?: return
            ZenStore.layout.dock.removeAt(index)
            val page = ZenStore.layout.pages.getOrNull(pageIndex) ?: return
            page.items += HomeItem(type = "app", packageName = ref.packageName, userSerial = ref.userSerial, col = col, row = row)
            ZenStore.save()
            refreshPager()
            return
        }
        val located = locate(itemId) ?: return
        val moving = located.second
        if (targetId != null && targetId != itemId) {
            val target = ZenStore.layout.pages.getOrNull(pageIndex)?.items?.firstOrNull { it.id == targetId }
            if (target != null && moving.type == "app" && target.type == "app") {
                val folderId = UUID.randomUUID().toString()
                val folder = com.zenos.launcher.model.Folder(folderId, getString(R.string.folder_default))
                folder.apps += AppRef(moving.packageName, moving.userSerial)
                folder.apps += AppRef(target.packageName, target.userSerial)
                ZenStore.layout.folders[folderId] = folder
                located.first.items.remove(moving)
                target.type.let {
                    ZenStore.layout.pages.forEach { page -> page.items.removeAll { it.id == target.id } }
                }
                ZenStore.layout.pages.getOrNull(pageIndex)?.items?.add(
                    HomeItem(type = "folder", folderId = folderId, col = target.col, row = target.row)
                )
                ZenStore.save()
                refreshPager()
                return
            }
            if (target != null && target.type == "folder" && moving.type == "app") {
                ZenStore.layout.folders[target.folderId]?.apps?.add(AppRef(moving.packageName, moving.userSerial))
                located.first.items.remove(moving)
                ZenStore.save()
                refreshPager()
                return
            }
        }
        located.first.items.remove(moving)
        moving.col = col
        moving.row = row
        ZenStore.layout.pages.getOrNull(pageIndex)?.items?.add(moving)
        ZenStore.save()
        refreshPager()
    }

    override fun onDropToDock(itemId: String, slot: Int) {
        if (itemId.startsWith("dock:")) return
        val located = locate(itemId) ?: return
        if (located.second.type != "app") return
        val ref = AppRef(located.second.packageName, located.second.userSerial)
        if (ZenStore.layout.dock.none { it.packageName == ref.packageName }) {
            if (ZenStore.layout.dock.size >= ZenStore.settings.dockSlots) {
                ZenStore.layout.dock.removeAt(ZenStore.layout.dock.lastIndex)
            }
            ZenStore.layout.dock += ref
        }
        located.first.items.remove(located.second)
        ZenStore.save()
        refreshPager()
    }

    override fun requestEdit() {
        editing = true
        editBar.visibility = View.VISIBLE
        editBar.removeAllViews()
        editBar.addView(button(getString(R.string.add_widget)) { showWidgetPicker() })
        editBar.addView(button(getString(R.string.add_page)) {
            ZenStore.layout.pages += HomePage()
            ZenStore.save()
            refreshPager()
        })
        editBar.addView(button(getString(R.string.remove_page)) {
            if (ZenStore.layout.pages.size > 1) {
                ZenStore.layout.pages.removeAt(ZenStore.layout.pages.lastIndex)
                ZenStore.save()
                refreshPager()
            }
        })
        editBar.addView(button(getString(R.string.wallpaper)) { showWallpaperPicker() })
        editBar.addView(button(getString(R.string.settings)) { startActivity(Intent(this, SettingsActivity::class.java)) })
        editBar.addView(button(getString(R.string.done)) {
            editing = false
            editBar.visibility = View.GONE
            refreshPager()
        })
        refreshPager()
    }

    override fun isEditing(): Boolean = editing

    private fun showWidgetPicker() {
        val kinds = arrayOf("Zen card", "Clock", "Date", "Weather", "Battery", "Device", "Music", "Android widget")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.add_widget)
            .setItems(kinds) { _, which ->
                if (which == kinds.lastIndex) {
                    val id = widgetHost.allocateAppWidgetId()
                    val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    try {
                        pickWidget.launch(intent)
                    } catch (_: Exception) {
                        widgetHost.deleteAppWidgetId(id)
                        Toast.makeText(this, getString(R.string.launch_failed), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val kind = listOf("dynamic", "clock", "date", "weather", "battery", "device", "music")[which]
                    val page = currentHomePage() ?: ZenStore.layout.pages.first()
                    page.items += HomeItem(type = "widget", widgetKind = kind, col = 0, row = 0, spanX = if (kind == "battery") 2 else 4, spanY = 2)
                    ZenStore.save()
                    refreshPager()
                }
            }
            .show()
    }

    private fun showWallpaperPicker() {
        val names = arrayOf("System wallpaper", "Aurora", "Dusk", "Day", "Android wallpaper picker")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.wallpaper)
            .setItems(names) { _, which ->
                when (which) {
                    0 -> ZenStore.settings.wallpaperPreset = "system"
                    1 -> ZenStore.settings.wallpaperPreset = "aurora"
                    2 -> ZenStore.settings.wallpaperPreset = "dusk"
                    3 -> ZenStore.settings.wallpaperPreset = "day"
                    else -> startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
                }
                ZenStore.save()
                applyWallpaper()
            }
            .show()
    }

    private fun locate(id: String): Pair<HomePage, HomeItem>? {
        ZenStore.layout.pages.forEach { page ->
            val item = page.items.firstOrNull { it.id == id }
            if (item != null) return page to item
        }
        return null
    }

    private fun button(text: String, click: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.contentDescription = text
        b.setOnClickListener { click() }
        return b
    }

    private fun showOnboarding() {
        val panel = GlassPanel(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(20), dp(20), dp(20))
        val title = TextView(this)
        title.text = getString(R.string.onboarding_title)
        title.setTextColor(getColor(R.color.zen_text))
        title.textSize = 32f
        val tag = TextView(this)
        tag.text = getString(R.string.tagline)
        tag.setTextColor(getColor(R.color.zen_text_secondary))
        val help = TextView(this)
        help.text = getString(R.string.gestures_help)
        help.setTextColor(getColor(R.color.zen_text))
        col.addView(title)
        col.addView(tag)
        col.addView(help)
        col.addView(button(getString(R.string.set_default)) { requestHomeRole() })
        col.addView(button(getString(R.string.done)) {
            ZenStore.settings.onboardingDone = true
            ZenStore.save()
            root.removeView(panel)
        })
        panel.addView(col)
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
        })
    }

    private fun requestHomeRole() {
        val roleManager = getSystemService(RoleManager::class.java)
        if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME) && !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
            startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            if (torchId == null) {
                torchId = cm.cameraIdList.firstOrNull { id ->
                    cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
            }
            val id = torchId ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            control.flash.text = getString(R.string.tile_flash) + if (torchOn) " ON" else " OFF"
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.launch_failed), Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleRotation() {
        if (!Settings.System.canWrite(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            return
        }
        val current = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
        Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (current == 1) 0 else 1)
    }

    private fun toggleDark() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val ui = getSystemService(android.app.UiModeManager::class.java)
                val night = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
                ui.setApplicationNightMode(if (night) android.app.UiModeManager.MODE_NIGHT_NO else android.app.UiModeManager.MODE_NIGHT_YES)
            }
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        ZenStore.settings.themeMode = if (ZenStore.settings.themeMode == "dark") "light" else "dark"
        ZenStore.save()
        com.zenos.launcher.ZenApp.applyTheme()
    }

    private fun loadWeather() {
        if (!ZenStore.settings.weatherConsent) return
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            return
        }
        Thread {
            try {
                val lm = getSystemService(LocationManager::class.java)
                val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (loc == null) return@Thread
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val text = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                val current = JSONObject(text).getJSONObject("current")
                val temp = current.optDouble("temperature_2m").toInt().toString() + "°"
                val code = current.optInt("weather_code")
                val condition = weatherText(code)
                runOnUiThread {
                    root.findViewsWithText(ArrayList(), "", View.FIND_VIEWS_WITH_CONTENT_DESCRIPTION)
                    walk(root) {
                        if (it is BuiltinWidgetView) it.applyWeather(temp, condition)
                    }
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun walk(view: View, block: (View) -> Unit) {
        block(view)
        if (view is ViewGroup) for (i in 0 until view.childCount) walk(view.getChildAt(i), block)
    }

    private fun weatherText(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55, 61, 63, 65 -> "Rain"
        71, 73, 75 -> "Snow"
        95, 96, 99 -> "Storm"
        else -> "Cloudy"
    }

    private fun registerPackageMonitor() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(packageReceiver, filter)
        }
    }

    private inner class PageAdapter : RecyclerView.Adapter<PageVH>() {
        override fun getItemCount(): Int = (if (ZenStore.settings.gestureRight) 1 else 0) + ZenStore.layout.pages.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val frame = FrameLayout(parent.context)
            frame.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            return PageVH(frame)
        }
        override fun onBindViewHolder(holder: PageVH, position: Int) {
            val frame = holder.itemView as FrameLayout
            frame.removeAllViews()
            val today = ZenStore.settings.gestureRight && position == 0
            if (today) {
                val panel = TodayPanel(this@LauncherActivity)
                panel.rebuild { pkg -> onOpenApp(AppRef(pkg)) }
                frame.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            } else {
                val index = position - if (ZenStore.settings.gestureRight) 1 else 0
                val page = HomePageView(this@LauncherActivity, this@LauncherActivity, repo, index, widgetHost)
                page.rebuild()
                frame.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        }
    }

    private class PageVH(view: View) : RecyclerView.ViewHolder(view)
}
