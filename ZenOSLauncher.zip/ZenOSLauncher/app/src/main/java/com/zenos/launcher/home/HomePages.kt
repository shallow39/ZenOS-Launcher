package com.zenos.launcher.home

import android.content.ClipData
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.zenos.launcher.apps.AppRepository
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.glass.GlassPanel
import com.zenos.launcher.model.AppRef
import com.zenos.launcher.model.HomeItem
import com.zenos.launcher.model.HomePage

class HomePageView(
    context: android.content.Context,
    private val host: HomeHost,
    private val repo: AppRepository,
    private val pageIndex: Int,
    private val widgetHost: android.appwidget.AppWidgetHost? = null
) : FrameLayout(context) {
    private val grid = FrameLayout(context)
    init {
        addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setOnLongClickListener {
            host.requestEdit()
            true
        }
        setOnDragListener { _, event -> handleDrag(event) }
        contentDescription = context.getString(com.zenos.launcher.R.string.cd_home)
    }

    fun rebuild() {
        grid.removeAllViews()
        val page = ZenStore.layout.pages.getOrNull(pageIndex) ?: return
        page.items.forEach { item ->
            val view = when (item.type) {
                "folder" -> folderView(item)
                "widget", "dynamic" -> widgetView(item)
                "awidget" -> boundWidget(item)
                else -> appView(item)
            }
            view.tag = item.id
            grid.addView(view)
        }
        requestLayout()
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        val page = ZenStore.layout.pages.getOrNull(pageIndex) ?: return
        val cols = columns()
        val rows = ZenStore.settings.gridRows
        val cellW = grid.width / cols.coerceAtLeast(1)
        val cellH = grid.height / rows.coerceAtLeast(1)
        page.items.forEach { item ->
            val child = grid.findViewWithTag<View>(item.id) ?: return@forEach
            val w = cellW * item.spanX
            val h = cellH * item.spanY
            val l = item.col * cellW
            val t = item.row * cellH
            child.layout(l, t, l + w, t + h)
        }
    }

    private fun appView(item: HomeItem): View {
        val cell = AppCellView(context)
        cell.itemId = item.id
        val ref = AppRef(item.packageName, item.userSerial)
        cell.appRef = ref
        val entry = repo.find(ref)
        if (entry == null) {
            cell.bindLabel(item.packageName)
        } else {
            cell.icon.setImageDrawable(maskIcon(context, entry.icon, iconSizePx(context)))
            cell.bindLabel(entry.label)
        }
        cell.badge.visibility = if (host.isEditing()) View.VISIBLE else View.GONE
        cell.badge.setOnClickListener { host.onRemoveItem(item) }
        cell.setOnClickListener {
            if (!host.isEditing()) host.onOpenApp(ref)
        }
        cell.setOnLongClickListener {
            startDrag(item.id, cell)
            true
        }
        return cell
    }

    private fun folderView(item: HomeItem): View {
        val cell = FolderPreview(context)
        cell.itemId = item.id
        cell.folderId = item.folderId
        val folder = ZenStore.layout.folders[item.folderId]
        cell.label.text = folder?.name ?: context.getString(com.zenos.launcher.R.string.folder_default)
        cell.label.visibility = if (ZenStore.settings.showLabels) View.VISIBLE else View.GONE
        cell.contentDescription = context.getString(com.zenos.launcher.R.string.cd_folder, cell.label.text)
        cell.iconBox.removeAllViews()
        val mini = LinearLayout(context)
        mini.orientation = LinearLayout.VERTICAL
        folder?.apps?.take(4)?.forEach { ref ->
            val iv = android.widget.ImageView(context)
            val entry = repo.find(ref)
            if (entry != null) iv.setImageDrawable(maskIcon(context, entry.icon, context.dp(18)))
            mini.addView(iv, LinearLayout.LayoutParams(context.dp(18), context.dp(18)))
        }
        cell.iconBox.addView(mini, FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        cell.badge.visibility = if (host.isEditing()) View.VISIBLE else View.GONE
        cell.badge.setOnClickListener { host.onRemoveItem(item) }
        cell.setOnClickListener { if (!host.isEditing()) host.onOpenFolder(item.folderId) }
        cell.setOnLongClickListener { startDrag(item.id, cell); true }
        return cell
    }

    private fun boundWidget(item: HomeItem): View {
        val manager = android.appwidget.AppWidgetManager.getInstance(context)
        val info = manager.getAppWidgetInfo(item.appWidgetId)
        val hostView = widgetHost?.createView(context, item.appWidgetId, info)
        if (hostView != null && info != null) {
            hostView.setAppWidget(item.appWidgetId, info)
            hostView.tag = item.id
            hostView.setOnLongClickListener { startDrag(item.id, hostView); true }
            return hostView
        }
        return widgetView(item)
    }

    private fun widgetView(item: HomeItem): View {
        val view = com.zenos.launcher.home.BuiltinWidgetView(context, item.widgetKind.ifBlank { "clock" })
        view.tag = item.id
        if (host.isEditing()) {
            view.setOnClickListener { host.onRemoveItem(item) }
            view.contentDescription = context.getString(com.zenos.launcher.R.string.cd_remove, item.widgetKind)
        }
        view.setOnLongClickListener { startDrag(item.id, view); true }
        return view
    }

    private fun startDrag(id: String, view: View): Boolean {
        val data = ClipData.newPlainText("zen-item", id)
        return view.startDragAndDrop(data, DragShadowBuilder(view), id, 0)
    }

    private fun handleDrag(event: DragEvent): Boolean {
        if (event.localState !is String) return false
        when (event.action) {
            DragEvent.ACTION_DRAG_STARTED -> return true
            DragEvent.ACTION_DRAG_ENTERED, DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_EXITED -> return true
            DragEvent.ACTION_DROP -> {
                val id = event.localState as String
                val cols = columns()
                val rows = ZenStore.settings.gridRows
                val col = ((event.x / (width / cols.coerceAtLeast(1))).toInt()).coerceIn(0, cols - 1)
                val row = ((event.y / (height / rows.coerceAtLeast(1))).toInt()).coerceIn(0, rows - 1)
                val target = hitItem(event.x, event.y)
                host.onDropItem(id, pageIndex, col, row, target)
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> return true
        }
        return false
    }

    private fun hitItem(x: Float, y: Float): String? {
        val page = ZenStore.layout.pages.getOrNull(pageIndex) ?: return null
        val cols = columns()
        val rows = ZenStore.settings.gridRows
        val col = ((x / (width / cols.coerceAtLeast(1))).toInt()).coerceIn(0, cols - 1)
        val row = ((y / (height / rows.coerceAtLeast(1))).toInt()).coerceIn(0, rows - 1)
        return page.items.firstOrNull {
            col in it.col until (it.col + it.spanX) && row in it.row until (it.row + it.spanY)
        }?.id
    }

    private fun columns(): Int {
        val base = ZenStore.settings.gridCols
        return if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
            maxOf(base, ZenStore.settings.gridRows).coerceAtMost(7)
        } else base
    }
}

class DockView(context: android.content.Context, private val host: HomeHost, private val repo: AppRepository) : GlassPanel(context) {
    private val row = LinearLayout(context)

    init {
        forceRadiusDp = 32f
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        contentDescription = context.getString(com.zenos.launcher.R.string.cd_dock)
        setOnDragListener { _, event ->
            if (event.action == DragEvent.ACTION_DROP && event.localState is String) {
                host.onDropToDock(event.localState as String, ZenStore.layout.dock.size)
                true
            } else event.action == DragEvent.ACTION_DRAG_STARTED || event.action == DragEvent.ACTION_DRAG_ENTERED || event.action == DragEvent.ACTION_DRAG_LOCATION
        }
    }

    fun rebuild() {
        row.removeAllViews()
        val slots = ZenStore.settings.dockSlots.coerceIn(3, 6)
        ZenStore.layout.dock.take(slots).forEachIndexed { index, ref ->
            val cell = AppCellView(context)
            cell.appRef = ref
            val entry = repo.find(ref)
            if (entry != null) {
                cell.icon.setImageDrawable(maskIcon(context, entry.icon, iconSizePx(context)))
                cell.bindLabel(entry.label)
            } else cell.bindLabel(ref.packageName)
            cell.label.visibility = View.GONE
            cell.setOnClickListener { host.onOpenApp(ref) }
            cell.setOnLongClickListener {
                cell.startDragAndDrop(ClipData.newPlainText("zen-dock", ref.key()), DragShadowBuilder(cell), "dock:$index", 0)
                true
            }
            val lp = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            row.addView(cell, lp)
        }
        refreshEffect()
    }
}
