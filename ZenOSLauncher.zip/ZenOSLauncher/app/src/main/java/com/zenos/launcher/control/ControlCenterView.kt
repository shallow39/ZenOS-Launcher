package com.zenos.launcher.control

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.zenos.launcher.R
import com.zenos.launcher.glass.GlassPanel
import com.zenos.launcher.home.dp

class ControlCenterView(context: Context) : GlassPanel(context) {
    val wifi = tile(context.getString(R.string.tile_wifi))
    val bluetooth = tile(context.getString(R.string.tile_bt))
    val flash = tile(context.getString(R.string.tile_flash))
    val rotate = tile(context.getString(R.string.tile_rotate))
    val dark = tile(context.getString(R.string.tile_dark))
    val settings = tile(context.getString(R.string.tile_settings))
    val battery = tile(context.getString(R.string.tile_battery))
    val brightness = SeekBar(context)
    val volume = TextView(context)

    init {
        forceRadiusDp = 32f
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(context.dp(16), context.dp(16), context.dp(16), context.dp(16))
        val grid = LinearLayout(context)
        grid.orientation = LinearLayout.VERTICAL
        val r1 = LinearLayout(context)
        val r2 = LinearLayout(context)
        listOf(wifi, bluetooth, flash, rotate).forEach { r1.addView(it, LinearLayout.LayoutParams(0, context.dp(72), 1f)) }
        listOf(dark, settings, battery).forEach { r2.addView(it, LinearLayout.LayoutParams(0, context.dp(72), 1f)) }
        grid.addView(r1)
        grid.addView(r2)
        col.addView(grid)
        val bLabel = TextView(context)
        bLabel.text = context.getString(R.string.brightness)
        bLabel.setTextColor(context.getColor(R.color.zen_text))
        bLabel.contentDescription = context.getString(R.string.brightness)
        col.addView(bLabel)
        brightness.max = 255
        brightness.contentDescription = context.getString(R.string.brightness)
        col.addView(brightness)
        volume.setTextColor(context.getColor(R.color.zen_accent))
        volume.text = context.getString(R.string.volume)
        volume.setPadding(0, context.dp(12), 0, context.dp(8))
        volume.contentDescription = context.getString(R.string.volume)
        col.addView(volume)
        addView(col)
        contentDescription = context.getString(R.string.cd_control)
    }

    private fun tile(label: String): TextView {
        val t = TextView(context)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(context.getColor(R.color.zen_text))
        t.textSize = 13f
        t.setPadding(context.dp(8), context.dp(8), context.dp(8), context.dp(8))
        t.contentDescription = label + ". " + context.getString(R.string.open_system_panel)
        t.setBackgroundColor(0x22FFFFFF)
        return t
    }

    fun open(action: String) {
        try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
