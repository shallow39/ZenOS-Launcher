package com.zenos.launcher.search

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zenos.launcher.R
import com.zenos.launcher.anim.AnimEngine
import com.zenos.launcher.apps.AppRepository
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.home.dp
import com.zenos.launcher.model.AppRef
import com.zenos.launcher.settings.SettingsActivity
import android.content.Intent

class SearchActivity : AppCompatActivity() {
    private val repo by lazy { AppRepository(this) }
    private lateinit var results: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(16))
        root.setBackgroundColor(getColor(R.color.zen_bg))
        val title = TextView(this)
        title.text = getString(R.string.search_title)
        title.setTextColor(getColor(R.color.zen_text))
        title.textSize = 28f
        val box = EditText(this)
        box.hint = getString(R.string.search_hint)
        box.contentDescription = getString(R.string.cd_search)
        box.setTextColor(getColor(R.color.zen_text))
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        val clear = Button(this)
        clear.text = getString(R.string.clear)
        clear.contentDescription = getString(R.string.clear)
        clear.setOnClickListener {
            box.setText("")
            ZenStore.settings.searchHistory.clear()
            ZenStore.save()
            render("")
        }
        results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(results)
        root.addView(title)
        root.addView(box)
        root.addView(clear)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        AnimEngine.play(root, "Search transition")
        box.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        box.setOnEditorActionListener { _, _, _ ->
            ZenStore.pushSearch(box.text.toString())
            false
        }
        render("")
    }

    private fun render(query: String) {
        results.removeAllViews()
        if (query.isBlank()) {
            header(getString(R.string.recent))
            ZenStore.settings.recentLaunches.take(6).forEach { pkg ->
                val app = repo.findByPackage(pkg)
                if (app != null) row(app.label) { open(AppRef(app.packageName, app.userSerial), query) }
            }
            header("History")
            ZenStore.settings.searchHistory.forEach { q -> row(q) { render(q) } }
            return
        }
        val apps = repo.apps().filter {
            it.label.contains(query, true) || it.packageName.contains(query, true)
        }
        apps.forEach { app -> row(app.label + "\n" + app.packageName) { open(AppRef(app.packageName, app.userSerial), query) } }
        val settingsHits = listOf(
            "Home screen", "Appearance", "Liquid Glass", "Animation Studio", "Performance", "Privacy", "Gestures"
        ).filter { it.contains(query, true) }
        settingsHits.forEach { name ->
            row(name) {
                ZenStore.pushSearch(query)
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("section", name))
            }
        }
        if (apps.isEmpty() && settingsHits.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.no_results)
            empty.setTextColor(getColor(R.color.zen_text_secondary))
            results.addView(empty)
        }
    }

    private fun open(ref: AppRef, query: String) {
        ZenStore.pushSearch(query)
        if (!repo.launch(ref)) android.widget.Toast.makeText(this, getString(R.string.launch_failed), android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun header(text: String) {
        val h = TextView(this)
        h.text = text
        h.setTextColor(getColor(R.color.zen_accent))
        h.setPadding(0, dp(10), 0, dp(4))
        results.addView(h)
    }

    private fun row(text: String, click: () -> Unit) {
        val t = TextView(this)
        t.text = text
        t.setTextColor(getColor(R.color.zen_text))
        t.textSize = 18f
        t.setPadding(0, dp(12), 0, dp(12))
        t.contentDescription = text
        t.setOnClickListener { click() }
        results.addView(t)
    }
}
