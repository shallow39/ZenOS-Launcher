package com.zenos.launcher.settings

import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.zenos.launcher.BuildConfig
import com.zenos.launcher.R
import com.zenos.launcher.ZenApp
import com.zenos.launcher.anim.AnimEngine
import com.zenos.launcher.apps.AppRepository
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.glass.GlassPanel
import com.zenos.launcher.home.BuiltinWidgetView
import com.zenos.launcher.home.dp
import com.zenos.launcher.model.AnimCatalog
import com.zenos.launcher.model.AnimClip
import com.zenos.launcher.notify.NotificationDashboardActivity
import java.io.OutputStreamWriter

class SettingsActivity : AppCompatActivity() {
    private val stack = ArrayDeque<View>()
    private lateinit var host: LinearLayout
    private var preview: View? = null
    private var playing = false

    private val exportTheme = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        contentResolver.openOutputStream(uri)?.use { out ->
            OutputStreamWriter(out).use { it.write(ZenStore.exportThemeJson("ZenOS Theme").toString(2)) }
        }
        android.widget.Toast.makeText(this, getString(R.string.theme_exported), android.widget.Toast.LENGTH_SHORT).show()
    }

    private val importTheme = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
        val ok = ZenStore.importThemeJson(text)
        android.widget.Toast.makeText(this, getString(if (ok) R.string.theme_imported else R.string.theme_invalid), android.widget.Toast.LENGTH_SHORT).show()
        if (ok) {
            ZenApp.applyTheme()
            recreate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        host = LinearLayout(this)
        host.orientation = LinearLayout.VERTICAL
        host.setBackgroundColor(getColor(R.color.zen_bg))
        val scroll = ScrollView(this)
        scroll.addView(host)
        setContentView(scroll)
        val section = intent.getStringExtra("section")
        when (section) {
            "Liquid Glass" -> showGlass()
            "Animation Studio" -> showStudio()
            "Performance" -> showPerformance()
            "Privacy" -> showPrivacy()
            "Gestures" -> showGestures()
            "Appearance" -> showAppearance()
            "Home screen" -> showHome()
            else -> showHub()
        }
    }

    override fun onBackPressed() {
        if (stack.size > 1) {
            stack.removeLast()
            show(stack.last())
        } else super.onBackPressed()
    }

    private fun show(view: View) {
        host.removeAllViews()
        host.addView(view)
    }

    private fun push(view: View) {
        stack.addLast(view)
        show(view)
    }

    private fun page(title: String): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(24))
        val t = TextView(this)
        t.text = title
        t.setTextColor(getColor(R.color.zen_text))
        t.textSize = 26f
        col.addView(t)
        return col
    }

    private fun showHub() {
        val col = page("ZenOS Settings")
        button(col, "Home screen") { push(homePage()) }
        button(col, "Appearance") { push(appearancePage()) }
        button(col, "Liquid Glass") { push(glassPage()) }
        button(col, "Animation Studio") { push(studioPage()) }
        button(col, "Apps") { push(appsPage()) }
        button(col, "Widgets") { push(widgetsPage()) }
        button(col, "Gestures") { push(gesturesPage()) }
        button(col, "Performance") { push(performancePage()) }
        button(col, "Notifications") { startActivity(Intent(this, NotificationDashboardActivity::class.java)) }
        button(col, "Privacy") { push(privacyPage()) }
        button(col, "Themes") { push(themePage()) }
        button(col, "About") { push(aboutPage()) }
        stack.clear()
        push(col)
    }

    private fun showHome() = push(homePage())
    private fun showAppearance() = push(appearancePage())
    private fun showGlass() = push(glassPage())
    private fun showStudio() = push(studioPage())
    private fun showGestures() = push(gesturesPage())
    private fun showPerformance() = push(performancePage())
    private fun showPrivacy() = push(privacyPage())

    private fun homePage(): View {
        val col = page("Home screen")
        choice(col, "Grid columns", listOf("4", "5", "6"), ZenStore.settings.gridCols.toString()) {
            ZenStore.settings.gridCols = it.toInt()
            ZenStore.save()
        }
        choice(col, "Grid rows", listOf("5", "6", "7"), ZenStore.settings.gridRows.toString()) {
            ZenStore.settings.gridRows = it.toInt()
            ZenStore.save()
        }
        choice(col, "Icon size", listOf("small", "medium", "large"), ZenStore.settings.iconSize) {
            ZenStore.settings.iconSize = it
            ZenStore.save()
        }
        choice(col, "Icon shape", listOf("squircle", "circle", "rounded", "square"), ZenStore.settings.iconShape) {
            ZenStore.settings.iconShape = it
            ZenStore.save()
        }
        toggle(col, "App labels", ZenStore.settings.showLabels) { ZenStore.settings.showLabels = it; ZenStore.save() }
        toggle(col, "Page indicator", ZenStore.settings.pageIndicator) { ZenStore.settings.pageIndicator = it; ZenStore.save() }
        choice(col, "Dock apps", listOf("3", "4", "5", "6"), ZenStore.settings.dockSlots.toString()) {
            ZenStore.settings.dockSlots = it.toInt()
            ZenStore.save()
        }
        toggle(col, "Add new installs to home", ZenStore.settings.addNewApps) { ZenStore.settings.addNewApps = it; ZenStore.save() }
        button(col, getString(R.string.reset_layout)) {
            ZenStore.layout.pages.clear()
            ZenStore.layout.dock.clear()
            ZenStore.layout.folders.clear()
            ZenStore.save()
            finish()
        }
        return col
    }

    private fun appearancePage(): View {
        val col = page("Appearance")
        choice(col, "Theme", listOf("system", "light", "dark"), ZenStore.settings.themeMode) {
            ZenStore.settings.themeMode = it
            ZenStore.save()
            ZenApp.applyTheme()
        }
        choice(col, "Accent", listOf("cyan", "blue", "purple", "green", "orange"), ZenStore.settings.accent) {
            ZenStore.settings.accent = it
            ZenStore.save()
        }
        choice(col, "Wallpaper", listOf("system", "aurora", "dusk", "day"), ZenStore.settings.wallpaperPreset) {
            ZenStore.settings.wallpaperPreset = it
            ZenStore.save()
        }
        slider(col, "Wallpaper dim", ZenStore.settings.wallpaperDim) { ZenStore.settings.wallpaperDim = it; ZenStore.save() }
        slider(col, "Wallpaper blur amount", ZenStore.settings.wallpaperBlur) { ZenStore.settings.wallpaperBlur = it; ZenStore.save() }
        toggle(col, "Parallax", ZenStore.settings.parallax) { ZenStore.settings.parallax = it; ZenStore.save() }
        button(col, "Open wallpaper picker") { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) }
        button(col, "Liquid Glass") { push(glassPage()) }
        return col
    }

    private fun glassPage(): View {
        val col = page("Liquid Glass")
        val previewPanel = GlassPanel(this)
        val label = TextView(this)
        label.text = "10:42\nGlass preview"
        label.gravity = Gravity.CENTER
        label.setTextColor(getColor(R.color.zen_text))
        label.textSize = 22f
        previewPanel.addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(140)))
        col.addView(previewPanel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))
        val refresh = { previewPanel.refreshEffect(); previewPanel.invalidate() }
        toggle(col, "Glass", ZenStore.settings.glassEnabled) { ZenStore.settings.glassEnabled = it; ZenStore.save(); refresh() }
        toggle(col, "Blur", ZenStore.settings.blurEnabled) { ZenStore.settings.blurEnabled = it; ZenStore.save(); refresh() }
        slider(col, "Blur", ZenStore.settings.glassBlur) { ZenStore.settings.glassBlur = it; ZenStore.save(); refresh() }
        slider(col, "Transparency", ZenStore.settings.glassAlpha) { ZenStore.settings.glassAlpha = it; ZenStore.save(); refresh() }
        slider(col, "Saturation", ZenStore.settings.glassSaturation) { ZenStore.settings.glassSaturation = it; ZenStore.save(); refresh() }
        slider(col, "Brightness", ZenStore.settings.glassBrightness) { ZenStore.settings.glassBrightness = it; ZenStore.save(); refresh() }
        slider(col, "Highlight", ZenStore.settings.glassHighlight) { ZenStore.settings.glassHighlight = it; ZenStore.save(); refresh() }
        slider(col, "Border", ZenStore.settings.glassBorder) { ZenStore.settings.glassBorder = it; ZenStore.save(); refresh() }
        slider(col, "Shadow", ZenStore.settings.glassShadow) { ZenStore.settings.glassShadow = it; ZenStore.save(); refresh() }
        slider(col, "Refraction", ZenStore.settings.glassRefraction) { ZenStore.settings.glassRefraction = it; ZenStore.save(); refresh() }
        choice(col, "Glass tint", listOf("system", "cyan", "blue", "purple", "green", "orange"), ZenStore.settings.glassTint) {
            ZenStore.settings.glassTint = it
            ZenStore.save()
            refresh()
        }
        button(col, "Reset Liquid Glass") {
            ZenStore.settings.glassEnabled = true
            ZenStore.settings.glassBlur = 42
            ZenStore.settings.glassAlpha = 58
            ZenStore.settings.glassTint = "cyan"
            ZenStore.save()
            push(glassPage())
        }
        refresh()
        return col
    }

    private fun studioPage(): View {
        val col = page(getString(R.string.anim_studio))
        val categories = AnimCatalog.categories
        var category = categories.first()
        val previewBox = GlassPanel(this)
        val dot = View(this)
        dot.setBackgroundColor(getColor(R.color.zen_accent))
        previewBox.addView(dot, android.widget.FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
        col.addView(previewBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(140)))
        preview = dot
        val catSpin = spinner(categories, category) { category = it }
        col.addView(catSpin)
        val clip = { ZenStore.clip(category) }
        val duration = labeledSeek(col, "Duration", clip().duration, 800) { clip().duration = it; ZenStore.save() }
        labeledSeek(col, "Delay", clip().delay, 400) { clip().delay = it; ZenStore.save() }
        labeledSeek(col, "Scale from", (clip().fromScale * 100).toInt(), 150) { clip().fromScale = it / 100f; ZenStore.save() }
        labeledSeek(col, "Scale to", (clip().toScale * 100).toInt(), 150) { clip().toScale = it / 100f; ZenStore.save() }
        labeledSeek(col, "Opacity from", (clip().fromAlpha * 100).toInt(), 100) { clip().fromAlpha = it / 100f; ZenStore.save() }
        labeledSeek(col, "Opacity to", (clip().toAlpha * 100).toInt(), 100) { clip().toAlpha = it / 100f; ZenStore.save() }
        labeledSeek(col, "Y from", clip().fromY.toInt() + 100, 200) { clip().fromY = (it - 100).toFloat(); ZenStore.save() }
        labeledSeek(col, "Rotation", clip().fromRot.toInt() + 180, 360) { clip().fromRot = (it - 180).toFloat(); ZenStore.save() }
        labeledSeek(col, "Blur", clip().fromBlur.toInt(), 40) { clip().fromBlur = it.toFloat(); ZenStore.save() }
        labeledSeek(col, "Spring stiffness", clip().stiffness.toInt(), 800) { clip().stiffness = it.toFloat(); ZenStore.save() }
        labeledSeek(col, "Damping", (clip().damping * 100).toInt(), 100) { clip().damping = it / 100f; ZenStore.save() }
        labeledSeek(col, "Bounce", (clip().bounce * 100).toInt(), 100) { clip().bounce = it / 100f; ZenStore.save() }
        labeledSeek(col, "Overshoot", (clip().overshoot * 50).toInt(), 150) { clip().overshoot = it / 50f; ZenStore.save() }
        col.addView(spinner(AnimCatalog.easings, clip().easing) { clip().easing = it; ZenStore.save() })
        val timeline = TextView(this)
        timeline.setTextColor(getColor(R.color.zen_text_secondary))
        timeline.text = "0ms ---- 100 ---- 200 ---- 300 ---- 400 ---- 500ms"
        col.addView(timeline)
        val row = LinearLayout(this)
        row.addView(buttonView("Play") {
            playing = true
            AnimEngine.play(dot, category) { playing = false }
        })
        row.addView(buttonView("Reset") {
            dot.translationX = 0f
            dot.translationY = 0f
            dot.scaleX = 1f
            dot.scaleY = 1f
            dot.alpha = 1f
            dot.rotation = 0f
        })
        col.addView(row)
        choice(col, "Preset", ZenStore.presets.keys.toList(), ZenStore.activePreset) {
            ZenStore.activePreset = it
            ZenStore.save()
            push(studioPage())
        }
        button(col, "Save as new preset") { savePreset() }
        button(col, "Duplicate preset") {
            val copy = ZenStore.activePreset + " copy"
            ZenStore.presets[copy] = ZenStore.presets[ZenStore.activePreset]?.mapValues { AnimClip(
                it.value.duration, it.value.delay, it.value.fromScale, it.value.toScale, it.value.fromAlpha, it.value.toAlpha,
                it.value.fromRot, it.value.toRot, it.value.fromX, it.value.toX, it.value.fromY, it.value.toY, it.value.fromBlur,
                it.value.toBlur, it.value.corner, it.value.shadow, it.value.stiffness, it.value.damping, it.value.bounce, it.value.overshoot, it.value.easing
            ) }?.toMutableMap() ?: mutableMapOf()
            ZenStore.activePreset = copy
            ZenStore.save()
        }
        button(col, "Delete preset") {
            if (ZenStore.presets.size > 1) {
                ZenStore.presets.remove(ZenStore.activePreset)
                ZenStore.activePreset = ZenStore.presets.keys.first()
                ZenStore.save()
                push(studioPage())
            }
        }
        button(col, "Reset animations") {
            ZenStore.seedPresets()
            push(studioPage())
        }
        duration.toString()
        return col
    }

    private fun savePreset() {
        val input = EditText(this)
        input.hint = "Preset name"
        AlertDialog.Builder(this)
            .setTitle("Save animation")
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = input.text.toString().ifBlank { "Custom" }
                val source = ZenStore.presets[ZenStore.activePreset] ?: mutableMapOf()
                ZenStore.presets[name] = source.mapValues { it.value.copy() }.toMutableMap()
                ZenStore.activePreset = name
                ZenStore.save()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun appsPage(): View {
        val col = page("Apps")
        val repo = AppRepository(this)
        button(col, "Hidden apps") {
            val hidden = page("Hidden apps")
            ZenStore.layout.hidden.forEach { pkg ->
                button(hidden, pkg) {
                    ZenStore.layout.hidden.remove(pkg)
                    ZenStore.save()
                    push(appsPage())
                }
            }
            if (ZenStore.layout.hidden.isEmpty()) {
                val t = TextView(this)
                t.text = getString(R.string.no_results)
                t.setTextColor(getColor(R.color.zen_text))
                hidden.addView(t)
            }
            push(hidden)
        }
        repo.apps().take(40).forEach { app ->
            button(col, "Hide ${app.label}") {
                if (app.packageName !in ZenStore.layout.hidden) ZenStore.layout.hidden += app.packageName
                ZenStore.save()
            }
        }
        button(col, "Default apps") { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
        return col
    }

    private fun widgetsPage(): View {
        val col = page("Widgets")
        toggle(col, "Today clock", ZenStore.settings.todayClock) { ZenStore.settings.todayClock = it; ZenStore.save() }
        toggle(col, "Today weather", ZenStore.settings.todayWeather) { ZenStore.settings.todayWeather = it; ZenStore.save() }
        toggle(col, "Today battery", ZenStore.settings.todayBattery) { ZenStore.settings.todayBattery = it; ZenStore.save() }
        toggle(col, "Today calendar", ZenStore.settings.todayCalendar) { ZenStore.settings.todayCalendar = it; ZenStore.save() }
        toggle(col, "Today recent apps", ZenStore.settings.todayRecent) { ZenStore.settings.todayRecent = it; ZenStore.save() }
        toggle(col, "Weather network lookup", ZenStore.settings.weatherConsent) {
            ZenStore.settings.weatherConsent = it
            ZenStore.save()
        }
        val note = TextView(this)
        note.text = getString(R.string.weather_off)
        note.setTextColor(getColor(R.color.zen_text_secondary))
        col.addView(note)
        val sample = BuiltinWidgetView(this, "battery")
        col.addView(sample, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(100)))
        return col
    }

    private fun gesturesPage(): View {
        val col = page("Gestures")
        toggle(col, "Swipe up: App Library", ZenStore.settings.gestureUp) { ZenStore.settings.gestureUp = it; ZenStore.save() }
        toggle(col, "Swipe down: Search", ZenStore.settings.gestureDown) { ZenStore.settings.gestureDown = it; ZenStore.save() }
        toggle(col, "Swipe right: Today", ZenStore.settings.gestureRight) { ZenStore.settings.gestureRight = it; ZenStore.save() }
        toggle(col, "Upper-right swipe: Control Center", ZenStore.settings.gestureControl) { ZenStore.settings.gestureControl = it; ZenStore.save() }
        val help = TextView(this)
        help.text = getString(R.string.gestures_help)
        help.setTextColor(getColor(R.color.zen_text))
        col.addView(help)
        return col
    }

    private fun performancePage(): View {
        val col = page("Performance")
        choice(col, "Mode", listOf("balanced", "performance", "battery"), ZenStore.settings.performanceMode) {
            ZenStore.settings.performanceMode = it
            ZenStore.save()
        }
        toggle(col, "Low-end mode", ZenStore.settings.lowEnd) { ZenStore.settings.lowEnd = it; ZenStore.save() }
        choice(col, "Animation speed", listOf("fast", "normal", "slow"), ZenStore.settings.animSpeed) {
            ZenStore.settings.animSpeed = it
            ZenStore.save()
        }
        toggle(col, "Reduce motion", ZenStore.settings.reduceMotion) { ZenStore.settings.reduceMotion = it; ZenStore.save() }
        choice(col, "Blur quality", listOf("high", "medium", "low"), if (ZenStore.settings.lowEnd) "low" else "high") {
            ZenStore.settings.lowEnd = it != "high"
            ZenStore.settings.blurEnabled = it != "low"
            ZenStore.save()
        }
        val note = TextView(this)
        note.text = "Performance mode reduces blur, shadows, and animation time. It does not change CPU or GPU clocks."
        note.setTextColor(getColor(R.color.zen_text_secondary))
        col.addView(note)
        button(col, "Screen time settings") {
            if (!hasUsageAccess()) startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            else startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        return col
    }

    private fun privacyPage(): View {
        val col = page(getString(R.string.privacy_title))
        val body = TextView(this)
        body.text = getString(R.string.privacy_body)
        body.setTextColor(getColor(R.color.zen_text))
        col.addView(body)
        return col
    }

    private fun themePage(): View {
        val col = page("Themes")
        button(col, getString(R.string.export_theme)) { exportTheme.launch("zenos-theme.json") }
        button(col, getString(R.string.import_theme)) { importTheme.launch(arrayOf("application/json", "text/plain", "*/*")) }
        button(col, getString(R.string.reset_all)) {
            AlertDialog.Builder(this)
                .setMessage(R.string.reset_confirm)
                .setPositiveButton(R.string.reset) { _, _ ->
                    ZenStore.settings = com.zenos.launcher.model.ZenSettings(onboardingDone = true)
                    ZenStore.seedPresets()
                    ZenStore.save()
                    ZenApp.applyTheme()
                    recreate()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        return col
    }

    private fun aboutPage(): View {
        val col = page(getString(R.string.about_title))
        val body = TextView(this)
        body.text = "ZenOS Launcher\n${getString(R.string.tagline)}\n${getString(R.string.version_label)} ${BuildConfig.VERSION_NAME}"
        body.setTextColor(getColor(R.color.zen_text))
        body.textSize = 16f
        col.addView(body)
        button(col, getString(R.string.licenses)) {
            val lic = page(getString(R.string.licenses))
            val t = TextView(this)
            t.text = getString(R.string.licenses_body)
            t.setTextColor(getColor(R.color.zen_text))
            lic.addView(t)
            push(lic)
        }
        return col
    }

    private fun button(col: LinearLayout, text: String, click: () -> Unit) {
        col.addView(buttonView(text, click))
    }

    private fun buttonView(text: String, click: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.contentDescription = text
        b.setOnClickListener { click() }
        return b
    }

    private fun toggle(col: LinearLayout, label: String, value: Boolean, on: (Boolean) -> Unit) {
        val row = Switch(this)
        row.text = label
        row.isChecked = value
        row.contentDescription = label
        row.setTextColor(getColor(R.color.zen_text))
        row.setOnCheckedChangeListener { _, checked -> on(checked) }
        col.addView(row)
    }

    private fun choice(col: LinearLayout, label: String, values: List<String>, current: String, on: (String) -> Unit) {
        val title = TextView(this)
        title.text = label
        title.setTextColor(getColor(R.color.zen_text_secondary))
        title.contentDescription = label
        col.addView(title)
        col.addView(spinner(values, current, on))
    }

    private fun spinner(values: List<String>, current: String, on: (String) -> Unit): Spinner {
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        val index = values.indexOf(current).coerceAtLeast(0)
        spin.setSelection(index)
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (values[position] != current) on(values[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spin.contentDescription = current
        return spin
    }

    private fun slider(col: LinearLayout, label: String, value: Int, on: (Int) -> Unit) {
        labeledSeek(col, label, value, 100, on)
    }

    private fun labeledSeek(col: LinearLayout, label: String, value: Int, max: Int, on: (Int) -> Unit): SeekBar {
        val title = TextView(this)
        title.text = "$label: $value"
        title.setTextColor(getColor(R.color.zen_text))
        title.contentDescription = label
        val seek = SeekBar(this)
        seek.max = max
        seek.progress = value.coerceIn(0, max)
        seek.contentDescription = label
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                title.text = "$label: $progress"
                if (fromUser) on(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(title)
        col.addView(seek)
        return seek
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
