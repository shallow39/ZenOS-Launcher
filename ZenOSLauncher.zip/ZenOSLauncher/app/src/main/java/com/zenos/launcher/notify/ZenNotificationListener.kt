package com.zenos.launcher.notify

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ZenNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        instance = this
        latest = activeNotifications?.toList().orEmpty()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        latest = activeNotifications?.toList().orEmpty()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        latest = activeNotifications?.toList().orEmpty()
    }

    companion object {
        var latest: List<StatusBarNotification> = emptyList()
        var instance: ZenNotificationListener? = null
    }
}
