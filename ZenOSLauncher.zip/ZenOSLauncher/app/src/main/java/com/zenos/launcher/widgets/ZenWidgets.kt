package com.zenos.launcher.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.RemoteViews
import com.zenos.launcher.R
import java.text.DateFormat
import java.util.Date

class ZenClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_clock)
            views.setTextViewText(R.id.widget_time, android.text.format.DateFormat.format("HH:mm", Date()))
            views.setTextViewText(R.id.widget_date, DateFormat.getDateInstance(DateFormat.FULL).format(Date()))
            manager.updateAppWidget(id, views)
        }
    }
}

class ZenBatteryWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0 && level >= 0) (level * 100 / scale) else 0
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_battery)
            views.setTextViewText(R.id.widget_battery, "$pct%")
            manager.updateAppWidget(id, views)
        }
    }
}
