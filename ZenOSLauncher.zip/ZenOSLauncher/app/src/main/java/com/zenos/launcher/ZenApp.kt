package com.zenos.launcher

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.zenos.launcher.data.ZenStore

class ZenApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ZenStore.init(this)
        applyTheme()
    }

    companion object {
        fun applyTheme() {
            val mode = when (ZenStore.settings.themeMode) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            AppCompatDelegate.setDefaultNightMode(mode)
        }
    }
}
