package com.zenos.launcher.notify

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zenos.launcher.R
import com.zenos.launcher.home.dp
import java.text.DateFormat
import java.util.Date

class NotificationDashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(16))
        root.setBackgroundColor(getColor(R.color.zen_bg))
        val title = TextView(this)
        title.text = getString(R.string.notif_title)
        title.setTextColor(getColor(R.color.zen_text))
        title.textSize = 28f
        root.addView(title)
        val explain = TextView(this)
        explain.text = getString(R.string.notif_explain)
        explain.setTextColor(getColor(R.color.zen_text_secondary))
        root.addView(explain)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll)
        setContentView(root)
        if (!listenerEnabled()) {
            val enable = Button(this)
            enable.text = getString(R.string.enable_notif)
            enable.contentDescription = getString(R.string.enable_notif)
            enable.setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            list.addView(enable)
            return
        }
        val notes = ZenNotificationListener.instance?.activeNotifications?.toList() ?: ZenNotificationListener.latest
        if (notes.isNullOrEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.no_notifs)
            empty.setTextColor(getColor(R.color.zen_text))
            list.addView(empty)
            return
        }
        notes.forEach { sbn ->
            val n = sbn.notification
            val card = TextView(this)
            val app = sbn.packageName
            val titleText = n.extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
            val body = n.extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
            val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(sbn.postTime))
            card.text = "$app\n$titleText\n$body\n$time"
            card.setTextColor(getColor(R.color.zen_text))
            card.setPadding(0, dp(12), 0, dp(12))
            card.contentDescription = "$titleText $body"
            card.setOnClickListener {
                ZenNotificationListener.instance?.cancelNotification(sbn.key)
                card.text = getString(R.string.dismiss)
            }
            list.addView(card)
        }
    }

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val me = ComponentName(this, ZenNotificationListener::class.java).flattenToString()
        return flat.contains(me) || flat.contains(packageName)
    }
}
