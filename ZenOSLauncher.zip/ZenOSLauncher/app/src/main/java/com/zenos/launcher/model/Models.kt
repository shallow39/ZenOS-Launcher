package com.zenos.launcher.model

import java.util.UUID

data class AppRef(
    val packageName: String,
    val userSerial: Long = 0L
) {
    fun key(): String = "$packageName#$userSerial"
}

data class HomeItem(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val packageName: String = "",
    val userSerial: Long = 0L,
    val folderId: String = "",
    val widgetKind: String = "",
    val appWidgetId: Int = -1,
    var col: Int = 0,
    var row: Int = 0,
    var spanX: Int = 1,
    var spanY: Int = 1
)

data class HomePage(
    val id: String = UUID.randomUUID().toString(),
    val items: MutableList<HomeItem> = mutableListOf()
)

data class Folder(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val apps: MutableList<AppRef> = mutableListOf()
)

data class HomeLayout(
    val pages: MutableList<HomePage> = mutableListOf(),
    val dock: MutableList<AppRef> = mutableListOf(),
    val folders: MutableMap<String, Folder> = mutableMapOf(),
    val hidden: MutableList<String> = mutableListOf()
)

data class ZenSettings(
    var themeMode: String = "dark",
    var accent: String = "cyan",
    var iconSize: String = "medium",
    var showLabels: Boolean = true,
    var iconShape: String = "squircle",
    var gridCols: Int = 4,
    var gridRows: Int = 6,
    var dockSlots: Int = 4,
    var pageIndicator: Boolean = true,
    var blurEnabled: Boolean = true,
    var glassEnabled: Boolean = true,
    var glassBlur: Int = 42,
    var glassAlpha: Int = 58,
    var glassSaturation: Int = 35,
    var glassBrightness: Int = 28,
    var glassHighlight: Int = 46,
    var glassBorder: Int = 40,
    var glassShadow: Int = 28,
    var glassRefraction: Int = 22,
    var glassTint: String = "cyan",
    var animSpeed: String = "normal",
    var pageTransition: String = "slide",
    var folderAnim: Boolean = true,
    var reduceMotion: Boolean = false,
    var performanceMode: String = "balanced",
    var lowEnd: Boolean = false,
    var addNewApps: Boolean = false,
    var wallpaperDim: Int = 28,
    var wallpaperBlur: Int = 0,
    var parallax: Boolean = true,
    var wallpaperPreset: String = "system",
    var weatherConsent: Boolean = false,
    var onboardingDone: Boolean = false,
    var gestureUp: Boolean = true,
    var gestureDown: Boolean = true,
    var gestureRight: Boolean = true,
    var gestureControl: Boolean = true,
    var todayClock: Boolean = true,
    var todayWeather: Boolean = true,
    var todayBattery: Boolean = true,
    var todayRecent: Boolean = true,
    var todayCalendar: Boolean = true,
    var searchHistory: MutableList<String> = mutableListOf(),
    var recentLaunches: MutableList<String> = mutableListOf()
)

data class AnimClip(
    var duration: Int = 320,
    var delay: Int = 0,
    var fromScale: Float = 0.94f,
    var toScale: Float = 1f,
    var fromAlpha: Float = 0f,
    var toAlpha: Float = 1f,
    var fromRot: Float = 0f,
    var toRot: Float = 0f,
    var fromX: Float = 0f,
    var toX: Float = 0f,
    var fromY: Float = 24f,
    var toY: Float = 0f,
    var fromBlur: Float = 8f,
    var toBlur: Float = 0f,
    var corner: Float = 28f,
    var shadow: Float = 0.25f,
    var stiffness: Float = 380f,
    var damping: Float = 0.72f,
    var bounce: Float = 0.1f,
    var overshoot: Float = 1.15f,
    var easing: String = "Spring"
)

object AnimCatalog {
    val categories = listOf(
        "Page swipe",
        "Page enter",
        "Page exit",
        "Icon appearance",
        "Icon press",
        "Icon rearrangement",
        "Home edit mode",
        "App launch scale",
        "App launch fade",
        "App launch slide",
        "App launch spring",
        "App closing",
        "Folder opening",
        "Folder closing",
        "Icon morph",
        "Background expansion",
        "Folder blur",
        "App Library entrance",
        "Category transition",
        "Search transition",
        "App icon animation",
        "Panel entrance",
        "Panel exit",
        "Tile press",
        "Blur transition",
        "Brightness panel",
        "Widget entrance",
        "Widget movement",
        "Widget resize",
        "Widget press"
    )

    val easings = listOf(
        "Linear", "Ease In", "Ease Out", "Ease In Out", "Cubic", "Quartic",
        "Quintic", "Back", "Elastic", "Bounce", "Spring", "Smooth"
    )

    fun defaultClip(name: String): AnimClip {
        val clip = AnimClip()
        when {
            name.contains("press", true) -> {
                clip.duration = 140
                clip.fromScale = 1f
                clip.toScale = 0.92f
                clip.fromAlpha = 1f
                clip.toAlpha = 1f
                clip.fromY = 0f
                clip.toY = 0f
            }
            name.contains("exit", true) || name.contains("closing", true) -> {
                clip.fromScale = 1f
                clip.toScale = 0.96f
                clip.fromAlpha = 1f
                clip.toAlpha = 0f
                clip.fromY = 0f
                clip.toY = 16f
            }
            name.contains("swipe", true) -> {
                clip.duration = 280
                clip.fromX = 40f
                clip.toX = 0f
                clip.fromAlpha = 1f
                clip.toAlpha = 1f
                clip.fromY = 0f
            }
        }
        return clip
    }
}
