package com.zenos.launcher.home

import android.app.ActivityManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.StatFs
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.zenos.launcher.R
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.glass.GlassPanel
import com.zenos.launcher.notify.ZenNotificationListener
import java.text.DateFormat
import java.util.Date

class ZenWidgetHost(context: Context, hostId: Int) : AppWidgetHost(context, hostId) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView {
        return AppWidgetHostView(context)
    }
}

class BuiltinWidgetView(context: Context, val kind: String) : GlassPanel(context) {
    private val title = TextView(context)
    private val body = TextView(context)
    private val extra = TextView(context)

    init {
        forceRadiusDp = 22f
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(context.dp(14), context.dp(12), context.dp(14), context.dp(12))
        title.setTextColor(context.getColor(R.color.zen_text))
        title.textSize = 28f
        body.setTextColor(context.getColor(R.color.zen_text_secondary))
        body.textSize = 14f
        extra.setTextColor(context.getColor(R.color.zen_text))
        extra.textSize = 15f
        col.addView(title)
        col.addView(body)
        col.addView(extra)
        addView(col)
        contentDescription = kind
        refresh()
    }

    fun refresh() {
        val now = Date()
        when (kind) {
            "clock" -> {
                title.text = android.text.format.DateFormat.format("HH:mm", now)
                body.text = DateFormat.getDateInstance(DateFormat.FULL).format(now)
                extra.text = greeting(context)
            }
            "date" -> {
                title.text = android.text.format.DateFormat.format("d", now)
                body.text = android.text.format.DateFormat.format("EEEE", now)
                extra.text = android.text.format.DateFormat.format("MMMM", now)
            }
            "battery" -> {
                val pct = batteryPercent(context)
                title.text = "$pct%"
                body.text = context.getString(R.string.widget_battery)
                extra.text = if (pct <= 20) "Low" else "OK"
            }
            "device" -> {
                val am = context.getSystemService(ActivityManager::class.java)
                val info = ActivityManager.MemoryInfo()
                am.getMemoryInfo(info)
                val used = ((info.totalMem - info.availMem) * 100 / info.totalMem.coerceAtLeast(1)).toInt()
                val stat = StatFs(context.filesDir.absolutePath)
                val free = stat.availableBytes / (1024 * 1024)
                title.text = "$used%"
                body.text = "RAM in use"
                extra.text = "$free MB free storage"
            }
            "music" -> {
                title.text = context.getString(R.string.widget_music)
                body.text = mediaTitle(context)
                extra.text = ""
            }
            "weather" -> {
                title.text = "--"
                body.text = context.getString(R.string.widget_weather)
                extra.text = if (ZenStore.settings.weatherConsent) context.getString(R.string.weather_waiting) else context.getString(R.string.weather_off)
            }
            else -> {
                title.text = android.text.format.DateFormat.format("HH:mm", now)
                body.text = DateFormat.getDateInstance(DateFormat.MEDIUM).format(now)
                extra.text = greeting(context)
            }
        }
    }

    fun applyWeather(temp: String, condition: String) {
        if (kind == "weather" || kind == "dynamic") {
            if (kind == "dynamic") extra.text = "$temp  $condition" else {
                title.text = temp
                extra.text = condition
            }
        }
    }

    companion object {
        fun greeting(context: Context): String {
            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            return when {
                hour < 12 -> context.getString(R.string.good_morning)
                hour < 18 -> context.getString(R.string.good_afternoon)
                else -> context.getString(R.string.good_evening)
            }
        }

        fun batteryPercent(context: Context): Int {
            val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            return if (scale > 0 && level >= 0) level * 100 / scale else 0
        }

        fun mediaTitle(context: Context): String {
            return try {
                val msm = context.getSystemService(MediaSessionManager::class.java) ?: return context.getString(R.string.music_none)
                val sessions = msm.getActiveSessions(android.content.ComponentName(context, ZenNotificationListener::class.java))
                val playing = sessions.firstOrNull {
                    it.playbackState?.state == PlaybackState.STATE_PLAYING
                } ?: sessions.firstOrNull()
                playing?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
                    ?: context.getString(R.string.music_none)
            } catch (_: Exception) {
                context.getString(R.string.music_none)
            }
        }
    }
}

class TodayPanel(context: Context) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        setPadding(context.dp(20), context.dp(48), context.dp(20), context.dp(96))
        contentDescription = context.getString(R.string.today)
    }

    fun rebuild(onOpen: (String) -> Unit) {
        removeAllViews()
        val s = ZenStore.settings
        if (s.todayClock) addCard(BuiltinWidgetView(context, "dynamic"))
        if (s.todayWeather) addCard(BuiltinWidgetView(context, "weather"))
        if (s.todayBattery) addCard(BuiltinWidgetView(context, "battery"))
        if (s.todayCalendar) {
            val cal = BuiltinWidgetView(context, "date")
            addCard(cal)
        }
        if (s.todayRecent) {
            val card = GlassPanel(context)
            val col = LinearLayout(context)
            col.orientation = VERTICAL
            col.setPadding(context.dp(14), context.dp(12), context.dp(14), context.dp(12))
            val h = TextView(context)
            h.text = context.getString(R.string.recent)
            h.setTextColor(context.getColor(R.color.zen_text))
            h.textSize = 16f
            col.addView(h)
            if (s.recentLaunches.isEmpty()) {
                val t = TextView(context)
                t.text = context.getString(R.string.no_results)
                t.setTextColor(context.getColor(R.color.zen_text_secondary))
                col.addView(t)
            } else {
                s.recentLaunches.take(5).forEach { pkg ->
                    val row = TextView(context)
                    row.text = pkg
                    row.setTextColor(context.getColor(R.color.zen_accent))
                    row.setPadding(0, context.dp(8), 0, context.dp(8))
                    row.contentDescription = pkg
                    row.setOnClickListener { onOpen(pkg) }
                    col.addView(row)
                }
            }
            card.addView(col)
            addCard(card)
        }
    }

    private fun addCard(view: View) {
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = context.dp(12)
        lp.height = context.dp(120)
        addView(view, lp)
    }
}
