package com.zenos.launcher.glass

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.widget.FrameLayout
import com.zenos.launcher.anim.AnimEngine
import com.zenos.launcher.data.ZenStore

object GlassPalette {
    fun accent(name: String): Int = when (name) {
        "blue" -> Color.parseColor("#3B82F6")
        "purple" -> Color.parseColor("#8B5CF6")
        "green" -> Color.parseColor("#22C55E")
        "orange" -> Color.parseColor("#F59E0B")
        "white" -> Color.parseColor("#F8FAFC")
        else -> Color.parseColor("#3EC6E0")
    }

    fun tintColor(): Int {
        val s = ZenStore.settings
        return if (s.glassTint == "system") accent(s.accent) else accent(s.glassTint)
    }
}

class GlassPanel @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG)
    var luminance: Float = 0.25f
    var forceRadiusDp: Float = 28f

    init {
        setWillNotDraw(false)
        stroke.style = Paint.Style.STROKE
    }

    fun refreshEffect() {
        val s = ZenStore.settings
        if (Build.VERSION.SDK_INT >= 31 && AnimEngine.blurAllowed() && s.glassBlur > 2) {
            val radius = (s.glassBlur / 100f) * 28f
            setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP))
        } else if (Build.VERSION.SDK_INT >= 31) {
            setRenderEffect(null)
        }
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val s = ZenStore.settings
        val d = resources.displayMetrics.density
        val r = forceRadiusDp * d
        val rect = RectF(d, d, width - d, height - d)
        val base = if (luminance > 0.62f) Color.parseColor("#101820") else Color.parseColor("#F7FBFF")
        val tint = GlassPalette.tintColor()
        val alpha = if (!s.glassEnabled) 210 else (40 + s.glassAlpha * 1.4f).toInt().coerceIn(30, 220)
        val brighten = if (luminance < 0.35f) s.glassBrightness else -s.glassBrightness / 3
        fill.shader = null
        fill.color = mix(base, tint, if (s.glassEnabled) s.glassSaturation / 180f else 0.05f, alpha, brighten)
        if (s.glassEnabled && s.glassShadow > 0) {
            setShadowLayer(s.glassShadow / 100f * 18f * d)
        }
        canvas.drawRoundRect(rect, r, r, fill)
        if (s.glassEnabled && s.glassHighlight > 0) {
            highlight.shader = LinearGradient(
                0f, 0f, 0f, height * 0.45f,
                Color.argb((s.glassHighlight * 1.4f).toInt().coerceIn(0, 160), 255, 255, 255),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
            val clip = Path()
            clip.addRoundRect(rect, r, r, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clip)
            canvas.drawRect(rect, highlight)
            canvas.restore()
        }
        if (s.glassEnabled && s.glassBorder > 0) {
            stroke.strokeWidth = d
            stroke.color = Color.argb((s.glassBorder * 1.6f).toInt().coerceIn(20, 200), 255, 255, 255)
            canvas.drawRoundRect(rect, r, r, stroke)
        }
        super.dispatchDraw(canvas)
    }

    private fun setShadowLayer(radius: Float) {
        fill.setShadowLayer(radius, 0f, radius * 0.35f, 0x55000000)
    }

    private fun mix(base: Int, tint: Int, amount: Float, alpha: Int, brighten: Int): Int {
        val a = amount.coerceIn(0f, 1f)
        var r = (Color.red(base) * (1 - a) + Color.red(tint) * a).toInt()
        var g = (Color.green(base) * (1 - a) + Color.green(tint) * a).toInt()
        var b = (Color.blue(base) * (1 - a) + Color.blue(tint) * a).toInt()
        r = (r + brighten).coerceIn(0, 255)
        g = (g + brighten).coerceIn(0, 255)
        b = (b + brighten).coerceIn(0, 255)
        return Color.argb(alpha, r, g, b)
    }
}
