package com.zenos.launcher.anim

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.AnticipateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.model.AnimClip
import kotlin.math.pow
import kotlin.math.sin

object AnimEngine {
    fun speedScale(): Float {
        val s = ZenStore.settings
        if (s.reduceMotion || s.performanceMode == "battery") return 0.55f
        if (s.lowEnd || s.performanceMode == "performance") return 0.7f
        return when (s.animSpeed) {
            "fast" -> 0.72f
            "slow" -> 1.35f
            else -> 1f
        }
    }

    fun blurAllowed(): Boolean {
        val s = ZenStore.settings
        return s.blurEnabled && s.glassEnabled && !s.lowEnd && s.performanceMode == "balanced" && !s.reduceMotion
    }

    fun play(view: View, category: String, reverse: Boolean = false, end: (() -> Unit)? = null) {
        val clip = ZenStore.clip(category)
        val scale = speedScale()
        val fromS = if (reverse) clip.toScale else clip.fromScale
        val toS = if (reverse) clip.fromScale else clip.toScale
        val fromA = if (reverse) clip.toAlpha else clip.fromAlpha
        val toA = if (reverse) clip.fromAlpha else clip.toAlpha
        val fromY = if (reverse) clip.toY else clip.fromY
        val toY = if (reverse) clip.fromY else clip.toY
        val fromX = if (reverse) clip.toX else clip.fromX
        val toX = if (reverse) clip.fromX else clip.toX
        view.scaleX = fromS
        view.scaleY = fromS
        view.alpha = fromA
        view.translationX = fromX
        view.translationY = fromY
        view.rotation = if (reverse) clip.toRot else clip.fromRot
        val anim = ObjectAnimator.ofPropertyValuesHolder(
            view,
            PropertyValuesHolder.ofFloat(View.SCALE_X, fromS, toS),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, fromS, toS),
            PropertyValuesHolder.ofFloat(View.ALPHA, fromA, toA),
            PropertyValuesHolder.ofFloat(View.TRANSLATION_X, fromX, toX),
            PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, fromY, toY),
            PropertyValuesHolder.ofFloat(View.ROTATION, if (reverse) clip.toRot else clip.fromRot, if (reverse) clip.fromRot else clip.toRot)
        )
        anim.startDelay = (clip.delay * scale).toLong()
        anim.duration = (clip.duration * scale).toLong().coerceAtLeast(60L)
        anim.interpolator = interpolator(clip)
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                end?.invoke()
            }
        })
        anim.start()
    }

    fun interpolator(clip: AnimClip): Interpolator {
        return when (clip.easing) {
            "Linear" -> LinearInterpolator()
            "Ease In" -> AccelerateInterpolator()
            "Ease Out" -> DecelerateInterpolator()
            "Ease In Out", "Smooth" -> AccelerateDecelerateInterpolator()
            "Cubic" -> AccelerateDecelerateInterpolator()
            "Quartic" -> DecelerateInterpolator(1.6f)
            "Quintic" -> DecelerateInterpolator(2f)
            "Back" -> OvershootInterpolator(clip.overshoot.coerceAtLeast(1f))
            "Elastic" -> Interpolator { t ->
                if (t == 0f || t == 1f) t else {
                    val p = 0.3f
                    val s = p / 4f
                    (2f.pow(-10f * t) * sin((t - s) * (2f * Math.PI.toFloat()) / p) + 1f)
                }
            }
            "Bounce" -> BounceInterpolator()
            "Spring" -> OvershootInterpolator((1f + clip.bounce).coerceIn(1f, 3f))
            else -> AnticipateInterpolator(0.4f)
        }
    }
}
