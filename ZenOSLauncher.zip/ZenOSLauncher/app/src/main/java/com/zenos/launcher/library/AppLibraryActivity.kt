package com.zenos.launcher.library

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.zenos.launcher.R
import com.zenos.launcher.apps.AppEntry
import com.zenos.launcher.apps.AppRepository
import com.zenos.launcher.data.ZenStore
import com.zenos.launcher.home.dp
import com.zenos.launcher.model.AppRef
import com.zenos.launcher.model.HomeItem
import com.zenos.launcher.model.HomePage

class AppLibraryActivity : AppCompatActivity() {
    private val repo by lazy { AppRepository(this) }
    private lateinit var list: LinearLayout
    private var category = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(16))
        root.setBackgroundColor(getColor(R.color.zen_bg))
        val title = TextView(this)
        title.text = getString(R.string.library_title)
        title.setTextColor(getColor(R.color.zen_text))
        title.textSize = 28f
        root.addView(title)
        val search = EditText(this)
        search.hint = getString(R.string.search_hint)
        search.contentDescription = getString(R.string.cd_search)
        search.setTextColor(getColor(R.color.zen_text))
        root.addView(search)
        val cats = LinearLayout(this)
        cats.orientation = LinearLayout.HORIZONTAL
        listOf("All", "Social", "Games", "Productivity", "Communication", "Media", "Photography", "Education", "Tools", "Other").forEach { name ->
            val b = Button(this)
            b.text = name
            b.contentDescription = name
            b.setOnClickListener { category = name; render(search.text.toString()) }
            cats.addView(b)
        }
        val catScroll = ScrollView(this)
        catScroll.addView(cats)
        root.addView(catScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)))
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(simple { render(search.text.toString()) })
        render("")
    }

    private fun render(query: String) {
        list.removeAllViews()
        val hidden = ZenStore.layout.hidden.toSet()
        val apps = repo.refresh().filter { it.packageName !in hidden }
            .filter { category == "All" || it.category == category }
            .filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
        var last = ""
        apps.forEach { app ->
            val letter = app.label.firstOrNull()?.uppercaseChar()?.toString() ?: "#"
            if (letter != last) {
                val h = TextView(this)
                h.text = letter
                h.setTextColor(getColor(R.color.zen_accent))
                h.textSize = 13f
                list.addView(h)
                last = letter
            }
            val row = TextView(this)
            row.text = app.label
            row.setTextColor(getColor(R.color.zen_text))
            row.textSize = 18f
            row.setPadding(0, dp(12), 0, dp(12))
            row.contentDescription = getString(R.string.cd_app_icon, app.label)
            row.setOnClickListener {
                if (!repo.launch(AppRef(app.packageName, app.userSerial))) {
                    android.widget.Toast.makeText(this, getString(R.string.launch_failed), android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            row.setOnLongClickListener {
                showMenu(app)
                true
            }
            list.addView(row)
        }
        if (apps.isEmpty()) {
            val empty = TextView(this)
            empty.text = getString(R.string.no_results)
            empty.setTextColor(getColor(R.color.zen_text_secondary))
            list.addView(empty)
        }
    }

    private fun showMenu(app: AppEntry) {
        val actions = arrayOf(
            getString(R.string.add_to_home),
            getString(R.string.add_to_dock),
            getString(R.string.hide),
            getString(R.string.app_info)
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> addHome(app)
                    1 -> addDock(app)
                    2 -> {
                        ZenStore.layout.hidden += app.packageName
                        ZenStore.save()
                        render("")
                    }
                    3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${app.packageName}")))
                }
            }
            .show()
    }

    private fun addHome(app: AppEntry) {
        val page = ZenStore.layout.pages.lastOrNull() ?: HomePage().also { ZenStore.layout.pages += it }
        page.items += HomeItem(type = "app", packageName = app.packageName, userSerial = app.userSerial, col = 0, row = 0)
        ZenStore.save()
        android.widget.Toast.makeText(this, getString(R.string.add_to_home), android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun addDock(app: AppEntry) {
        val ref = AppRef(app.packageName, app.userSerial)
        if (ZenStore.layout.dock.none { it.packageName == app.packageName }) {
            if (ZenStore.layout.dock.size >= ZenStore.settings.dockSlots) ZenStore.layout.dock.removeAt(0)
            ZenStore.layout.dock += ref
            ZenStore.save()
        }
    }
}

private fun simple(on: (String) -> Unit) = object : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { on(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
