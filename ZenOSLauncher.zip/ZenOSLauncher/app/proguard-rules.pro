# ZenOS Launcher ProGuard rules
-keep class com.zenos.launcher.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
