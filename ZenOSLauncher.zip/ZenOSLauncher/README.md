# ZenOS Launcher

ZenOS Launcher is an original Android home application. Tagline: "Your phone. Your layout."

It is a real launcher, not a web page. After you set it as the default Home app, the Home button opens ZenOS. Branding, icons, and wallpapers in this project are original. It does not include Apple, Xiaomi, or vivo assets.

## 1. Open the project

1. Install Android Studio Ladybug or newer (JDK 17).
2. Extract `ZenOSLauncher.zip`.
3. Choose **Open** and select the `ZenOSLauncher` folder.
4. Let Android Studio download the Gradle wrapper, Android Gradle Plugin 8.7.3, and SDK 35 if they are not installed yet.

## 2. Required Android Studio version

- Android Studio Ladybug (2024.2) or newer
- Android SDK 35
- Android SDK Build-Tools
- JDK 17

## 3. Required JDK

JDK 17. Android Studio's embedded JDK is enough.

## 4. How to build

In Android Studio: **Build > Make Project**, then **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

From a terminal, after the wrapper is present:

```bash
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

Outputs:

- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release-unsigned.apk`

The release APK is unsigned. No signing credentials are included.

## 5. How to install

Copy the debug APK to the phone and open it, or run the `app` configuration from Android Studio. Allow install from the source you use.

## 6. Set ZenOS as the default launcher

On the phone:

Settings → Apps → Default apps → Home app → ZenOS Launcher

You can also use **Set as default launcher** on the first-run card. That asks Android for the Home role. ZenOS never bypasses the lock screen.

## 7. Optional notification access

ZenOS does not replace the system notification shade. The notification dashboard is optional.

Settings → Notifications, or the battery tile in Control Center, explains the permission and opens Android's notification listener settings. Allow **ZenOS notification dashboard** only if you want that screen. Notifications stay on the device.

## 8. Liquid Glass

Settings → Liquid Glass.

Glass, blur, transparency, saturation, brightness, highlight, border, shadow, refraction, and tint update the live preview. Blur uses a hardware render effect on Android 12 and newer, and turns off in low-end or performance mode. **Reset Liquid Glass** restores the default glass values.

## 9. Animation Studio

Settings → Animation Studio.

Pick a category, move the sliders, choose an easing, then Play. Presets can be saved, duplicated, deleted, and reset. The active preset is what the launcher uses for page, folder, search, control center, and launch motion.

## 10. Import and export themes

Settings → Themes.

Export writes a JSON theme file. Import reads that JSON only. Theme files are data. ZenOS does not execute code from them. A theme stores colors, wallpaper preset, icon options, glass settings, animation settings, grid, and dock size.

## 11. Troubleshooting

- ZenOS does not appear as a Home app: confirm the APK installed, then reopen Default apps → Home app.
- App list is empty: the manifest requests package visibility for a launcher. Reinstall and open ZenOS once.
- A widget will not bind: pick it again from Edit home → Add widget → Android widget, and accept the bind prompt.
- Brightness or rotation does nothing: Android requires "modify system settings". ZenOS opens that page instead of pretending to change a protected setting.
- Flashlight does nothing: this phone may not expose a torch to third-party apps.
- Weather stays off: turn on weather lookup in Widgets and allow location. ZenOS calls a forecast only after that consent.
- Blur looks flat: low-end mode or performance mode disables expensive blur on purpose.
- Layout disappeared: layout is stored in app files `layout.json`. Clearing app storage resets it.

## Gestures

- Swipe left and right between home pages
- Swipe right onto Today when that gesture is enabled
- Swipe up for the App Library
- Swipe down for search
- Swipe down from the upper-right for Control Center
- Long-press an empty area to edit the home screen
- Long-press an icon to drag it. Drop it on another icon to make a folder.

## Privacy

ZenOS works offline. It does not upload the app list, notifications, contacts, or location. Weather is the only network feature, and only after you enable it.
